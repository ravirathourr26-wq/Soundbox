package np.soundbox.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Store.init(context)
        if (!Prefs.autoStart) return
        SpeechManager.init(context)
        SoundboxListenerService.rebind(context)
        if (Prefs.keepAlive) KeepAliveService.start(context)
    }
}
