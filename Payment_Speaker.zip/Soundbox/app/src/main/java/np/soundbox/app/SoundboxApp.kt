package np.soundbox.app

import android.app.Application

class SoundboxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        VoicePack.restore(this)
        FastVoice.restoreFromDisk(this)
        SpeechManager.init(this)
    }
}
