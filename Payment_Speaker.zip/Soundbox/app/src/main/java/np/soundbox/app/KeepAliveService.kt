package np.soundbox.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Shows a small permanent notification so Android keeps Payment Speaker alive and responsive,
 * and keeps the voice engine warm. Nothing is sent anywhere.
 */
class KeepAliveService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val warm = object : Runnable {
        override fun run() {
            SpeechManager.warmUp()
            handler.postDelayed(this, 120_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Payment Speaker running", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Payment Speaker is listening")
            .setContentText("Monitoring for incoming payments")
            .setSmallIcon(R.drawable.ic_stat_speaker)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, n)
            }
            lastError.value = ""
        } catch (e: Exception) {
            lastError.value = e.javaClass.simpleName + ": " + (e.message ?: "")
            Log.e("Payment Speaker", "startForeground failed", e)
            stopSelf()
            return START_NOT_STICKY
        }
        handler.removeCallbacks(warm)
        handler.postDelayed(warm, 120_000L)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(warm)
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "soundbox_keep"

        /** Last error when starting the background service (empty = none). */
        val lastError = MutableStateFlow("")

        @Suppress("DEPRECATION")
        fun isRunning(ctx: Context): Boolean {
            return try {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                am.getRunningServices(Int.MAX_VALUE).any { it.service.className == KeepAliveService::class.java.name }
            } catch (e: Exception) {
                false
            }
        }

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, KeepAliveService::class.java))
            } catch (e: Exception) {
                lastError.value = e.javaClass.simpleName + ": " + (e.message ?: "")
                Log.w("Payment Speaker", "Could not start keep-alive service", e)
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, KeepAliveService::class.java))
            } catch (e: Exception) {
                Log.w("Payment Speaker", "Could not stop keep-alive service", e)
            }
        }
    }
}
