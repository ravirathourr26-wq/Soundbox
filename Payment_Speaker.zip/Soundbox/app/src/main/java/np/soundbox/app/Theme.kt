package np.soundbox.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Brand {
    val Green = Color(0xFF0E7A43)
    val GreenDark = Color(0xFF085A31)
    val GreenLight = Color(0xFFE6F4EC)
    val Bg = Color(0xFFF5F7F6)
    val Ink = Color(0xFF14201A)
    val Muted = Color(0xFF6B7A72)
    val Line = Color(0xFFE3E9E5)
    val Warn = Color(0xFFB45309)
    val Bad = Color(0xFFB3261E)
}

@Composable
fun SoundboxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Brand.Green,
            onPrimary = Color.White,
            secondary = Brand.Green,
            background = Brand.Bg,
            surface = Color.White,
            onSurface = Brand.Ink,
            outline = Brand.Line
        ),
        content = content
    )
}
