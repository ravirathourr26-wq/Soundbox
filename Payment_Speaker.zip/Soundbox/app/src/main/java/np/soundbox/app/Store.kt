package np.soundbox.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class Payment(val amount: Double, val pkg: String, val time: Long)

data class DebugEntry(val time: Long, val pkg: String, val title: String, val text: String)

/** Local-only storage (SharedPreferences + JSON). Nothing is ever sent anywhere. */
object Store {
    private const val MAX_PAYMENTS = 2000
    const val MAX_DEBUG = 50

    lateinit var prefs: SharedPreferences
        private set
    private var inited = false

    val payments = MutableStateFlow<List<Payment>>(emptyList())
    val debug = MutableStateFlow<List<DebugEntry>>(emptyList())
    val lastDecision = MutableStateFlow("")

    @Synchronized
    fun init(context: Context) {
        if (inited) return
        prefs = context.applicationContext.getSharedPreferences("soundbox", Context.MODE_PRIVATE)
        payments.value = loadPayments()
        debug.value = loadDebug()
        inited = true
    }

    @Synchronized
    fun addPayment(p: Payment) {
        val list = (listOf(p) + payments.value).take(MAX_PAYMENTS)
        payments.value = list
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("a", it.amount).put("p", it.pkg).put("t", it.time)) }
        prefs.edit().putString("payments", arr.toString()).apply()
    }

    @Synchronized
    fun clearPayments() {
        payments.value = emptyList()
        prefs.edit().remove("payments").apply()
    }

    @Synchronized
    fun addDebug(e: DebugEntry) {
        val list = (listOf(e) + debug.value).take(MAX_DEBUG)
        debug.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("t", it.time).put("p", it.pkg).put("ti", it.title).put("tx", it.text))
        }
        prefs.edit().putString("debug", arr.toString()).apply()
    }

    @Synchronized
    fun clearDebug() {
        debug.value = emptyList()
        prefs.edit().remove("debug").apply()
    }

    private fun loadPayments(): List<Payment> = try {
        val arr = JSONArray(prefs.getString("payments", "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Payment(o.getDouble("a"), o.getString("p"), o.getLong("t"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun loadDebug(): List<DebugEntry> = try {
        val arr = JSONArray(prefs.getString("debug", "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            DebugEntry(o.getLong("t"), o.getString("p"), o.getString("ti"), o.getString("tx"))
        }
    } catch (e: Exception) {
        emptyList()
    }
}
