package np.soundbox.app

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SoundboxListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = true
        Log.i(TAG, "Listener connected")
        if (Prefs.keepAlive) KeepAliveService.start(this)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        connected = false
        Log.w(TAG, "Listener disconnected, requesting rebind")
        rebind(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling notification", e)
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val pkg: String = sbn.packageName ?: return
        val extras = sbn.notification?.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val body = if (big.isNotBlank()) big else text

        if (Prefs.debugEnabled && pkg != packageName) {
            Store.addDebug(DebugEntry(System.currentTimeMillis(), pkg, title, body))
        }

        val listed = pkg in Prefs.allowedPackages()
        if (!listed) {
            if (!Prefs.allApps || pkg == packageName || pkg in Prefs.BLOCKED_PACKAGES) return
        }

        // Only remember "ignored" reasons for apps in the allowed list (others would flood the line)
        fun note(msg: String) {
            if (listed) decide(msg)
        }

        val lower = "$title $body".lowercase()
        val neg = Prefs.NEGATIVE_REGEX.find(lower)?.value
            ?: Prefs.NEGATIVE_WORDS.firstOrNull { lower.contains(it) }
        if (neg != null) {
            note("Ignored: found word \"$neg\"")
            return
        }
        if (Prefs.keywords().none { lower.contains(it) }) {
            note("Ignored: no 'received' keyword found")
            return
        }

        val amount = AmountParser.parse("$title $body")
        if (amount == null) {
            note("Ignored: amount not found")
            return
        }

        // Ignore duplicates: same package + amount within 10 seconds
        val key = "$pkg|$amount"
        val now = SystemClock.elapsedRealtime()
        synchronized(recent) {
            val last = recent[key]
            if (last != null && now - last < DEDUPE_MS) {
                note("Ignored: duplicate within 10 seconds")
                return
            }
            recent[key] = now
            recent.entries.removeAll { now - it.value > 60_000 }
        }

        if (Prefs.maxVolume) {
            // Raise the volume the moment a payment is detected, and once more shortly after,
            // in case the phone lowers it again.
            SpeechManager.raiseVolume(this)
            // Retry on the main thread because some devices delay or override
            // the first audio stream adjustment after a notification arrives.
            val handler = Handler(Looper.getMainLooper())
            handler.postDelayed({ if (Prefs.maxVolume) SpeechManager.raiseVolume(applicationContext) }, 250L)
            handler.postDelayed({ if (Prefs.maxVolume) SpeechManager.raiseVolume(applicationContext) }, 900L)
        }
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "soundbox:announce").acquire(15_000L)
        } catch (e: Exception) {
            Log.w(TAG, "wake lock failed", e)
        }
        SpeechManager.speakAmount(AmountParser.format(amount))
        val ageSec = (System.currentTimeMillis() - sbn.postTime) / 1000
        decide("Announced: Rs ${AmountParser.format(amount)} from $pkg (notification age ${ageSec}s)")
        Store.addPayment(Payment(amount, pkg, System.currentTimeMillis()))
    }

    private fun decide(msg: String) {
        val t = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())
        Store.lastDecision.value = "$t  $msg"
    }

    companion object {
        private const val TAG = "Soundbox"
        private const val DEDUPE_MS = 10_000L

        @Volatile
        var connected = false

        private val recent = HashMap<String, Long>()

        fun rebind(ctx: Context) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(ctx, SoundboxListenerService::class.java)
                )
            } catch (e: Exception) {
                Log.w(TAG, "requestRebind failed", e)
            }
        }
    }
}
