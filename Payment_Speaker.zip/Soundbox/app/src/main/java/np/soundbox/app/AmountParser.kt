package np.soundbox.app

import java.util.Locale

object AmountParser {
    // "Rs. 500", "Rs 1,500.50", "NPR 500", "रु 500", "रू. 500"
    private val prefixRegex = Regex(
        """(?<![A-Za-z])(?:rs|npr|रु|रू|₹)\.?\s*([0-9][0-9,]*(?:\.[0-9]+)?)""",
        RegexOption.IGNORE_CASE
    )

    // "500 NPR", "500 Rs", "500 रुपैयाँ"
    private val suffixRegex = Regex(
        """([0-9][0-9,]*(?:\.[0-9]+)?)\s*(?:rs|npr|रु|रू|rupees)(?![A-Za-z])""",
        RegexOption.IGNORE_CASE
    )

    private fun normalizeDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            if (c in '\u0966'..'\u096F') sb.append('0' + (c - '\u0966')) else sb.append(c)
        }
        return sb.toString()
    }

    fun parse(raw: String): Double? {
        val text = normalizeDigits(raw)
        val m = prefixRegex.find(text) ?: suffixRegex.find(text) ?: return null
        val value = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        return if (value > 0.0) value else null
    }

    /** Plain number for speech, e.g. "500" or "1500.50" */
    fun format(amount: Double): String =
        if (amount == Math.floor(amount) && amount < 1e12) amount.toLong().toString()
        else String.format(Locale.US, "%.2f", amount)

    /** Number with thousands separators for display, e.g. "1,500" or "1,500.50" */
    fun pretty(amount: Double): String =
        if (amount == Math.floor(amount) && amount < 1e12) String.format(Locale.US, "%,d", amount.toLong())
        else String.format(Locale.US, "%,.2f", amount)
}
