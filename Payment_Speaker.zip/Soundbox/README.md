# Soundbox – eSewa payment announcer (Android, Kotlin + Jetpack Compose)

Reads eSewa "payment received" notifications and speaks the amount aloud
(e.g. "eSewa मा 500 रुपैयाँ प्राप्त भयो"). Fully offline: the app has **no INTERNET
permission** and stores everything (history, debug log, settings) only on the phone.

## Build a debug APK
1. Install **Android Studio** (Koala 2024.1 or newer; bundled JDK 17).
2. `File > Open…` and choose the `Soundbox` folder. Wait for Gradle sync
   (internet is needed once to download Gradle 8.7 and the libraries).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Click **locate** in the popup, or open `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy the APK to the phone and open it (allow "Install unknown apps"),
   or with USB debugging: `adb install -r app-debug.apk`.

## First-time setup on the phone
1. Open Soundbox and allow the notification permission (Android 13+).
2. Tap **Open Notification Access settings** and turn **Soundbox** ON.
   - Sideloaded apps on Android 13+: if the toggle is greyed out, go to
     `Settings > Apps > Soundbox > ⋮ (top-right) > Allow restricted settings`, then retry.
3. Tap the battery button and choose **Allow**. On Xiaomi / Oppo / Vivo / Realme / Samsung also enable
   "Autostart" and set battery to "No restrictions" for Soundbox, and lock the app in Recents.
4. Tap **Test voice**. If it speaks Hindi/English instead of Nepali, install the Nepali voice:
   `Settings > System > Languages > Text-to-speech output > Google > ⚙ > Install voice data`
   (the Home screen shows which language was actually used).

## Finding the real eSewa notification format
Open the **Debug** tab (capture is on by default), receive an eSewa notification, and look at the raw
package / title / text. **Copy all** puts it on the clipboard. Then adjust:
- **Settings > Allowed package names** if the package differs,
- **Settings > keywords** if the wording differs,
- the regex in `AmountParser.kt` if the amount format differs.

## Behaviour
- Spoken only if: package is allowed, text has a "received" keyword, and none of
  sent/paid/debited/failed (see `Prefs.NEGATIVE_WORDS`).
- Same package + amount within 10 s is ignored.
- Speech is queued (`QUEUE_ADD`); language order Nepali → Hindi → English.
- `requestRebind` is called on disconnect and after boot.

## Code map (`app/src/main/java/np/soundbox/app/`)
`SoundboxListenerService`, `AmountParser`, `SpeechManager`, `Store` (history + debug log),
`Prefs`, `BootReceiver`, `MainActivity`, `Screens`.
