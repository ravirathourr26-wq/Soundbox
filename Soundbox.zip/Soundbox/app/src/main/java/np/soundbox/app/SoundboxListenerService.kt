package np.soundbox.app

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class SoundboxListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = true
        Log.i(TAG, "Listener connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        connected = false
        Log.w(TAG, "Listener disconnected, requesting rebind")
        rebind(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling notification", e)
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val pkg: String = sbn.packageName ?: return
        val extras = sbn.notification?.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val body = if (big.isNotBlank()) big else text

        if (Prefs.debugEnabled && pkg != packageName) {
            Store.addDebug(DebugEntry(System.currentTimeMillis(), pkg, title, body))
        }

        if (pkg !in Prefs.allowedPackages()) return

        val lower = "$title $body".lowercase()
        if (Prefs.NEGATIVE_WORDS.any { lower.contains(it) }) return
        if (Prefs.keywords().none { lower.contains(it) }) return

        val amount = AmountParser.parse("$title $body") ?: return

        // Ignore duplicates: same package + amount within 10 seconds
        val key = "$pkg|$amount"
        val now = SystemClock.elapsedRealtime()
        synchronized(recent) {
            val last = recent[key]
            if (last != null && now - last < DEDUPE_MS) return
            recent[key] = now
            recent.entries.removeAll { now - it.value > 60_000 }
        }

        Store.addPayment(Payment(amount, pkg, System.currentTimeMillis()))
        SpeechManager.speakAmount(AmountParser.format(amount))
    }

    companion object {
        private const val TAG = "Soundbox"
        private const val DEDUPE_MS = 10_000L

        @Volatile
        var connected = false

        private val recent = HashMap<String, Long>()

        fun rebind(ctx: Context) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(ctx, SoundboxListenerService::class.java)
                )
            } catch (e: Exception) {
                Log.w(TAG, "requestRebind failed", e)
            }
        }
    }
}
