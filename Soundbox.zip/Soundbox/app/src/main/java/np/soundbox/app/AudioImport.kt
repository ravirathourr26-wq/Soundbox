package np.soundbox.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Reads audio files chosen by the user (mp3, m4a, wav, ogg, opus, amr...) as 16 kHz mono samples. */
object AudioImport {
    private const val TAG = "Soundbox"

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: ""
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    /** First number in a file name ("07 hundred.m4a" -> 7), used to put files in order. */
    fun numberIn(name: String): Int {
        val m = Regex("\\d+").find(name)
        return m?.value?.toIntOrNull() ?: Int.MAX_VALUE
    }

    /** Null if the file cannot be read as audio. */
    fun decode(ctx: Context, uri: Uri): ShortArray? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until extractor.trackCount) {
                val m = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("audio/")) {
                    track = i
                    break
                }
            }
            if (track < 0) return null
            extractor.selectTrack(track)
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(format, null, null, 0)
            c.start()
            val info = MediaCodec.BufferInfo()
            val pcm = ByteArrayOutputStream()
            var inputDone = false
            var outputDone = false
            val deadline = System.currentTimeMillis() + 20_000L
            while (!outputDone && System.currentTimeMillis() < deadline) {
                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val ib = c.getInputBuffer(ii) ?: return null
                        val n = extractor.readSampleData(ib, 0)
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val chunk = ByteArray(info.size)
                        ob.get(chunk)
                        pcm.write(chunk)
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            val bytes = pcm.toByteArray()
            if (bytes.size < 2 || channels < 1 || rate < 8000) return null
            return toMono16k(bytes, rate, channels)
        } catch (e: Exception) {
            Log.w(TAG, "Could not read audio file", e)
            return null
        } finally {
            try {
                codec?.stop()
            } catch (e: Exception) {
            }
            try {
                codec?.release()
            } catch (e: Exception) {
            }
            try {
                extractor.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun toMono16k(bytes: ByteArray, rate: Int, channels: Int): ShortArray {
        val total = bytes.size / 2
        val sh = ShortArray(total)
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(sh)
        val frames = total / channels
        val mono = FloatArray(frames)
        for (f in 0 until frames) {
            var sum = 0f
            for (ch in 0 until channels) sum += sh[f * channels + ch]
            mono[f] = sum / channels
        }
        val outLen = (frames.toLong() * 16000L / rate).toInt()
        val out = ShortArray(outLen)
        val ratio = rate.toDouble() / 16000.0
        for (i in 0 until outLen) {
            val pos = i * ratio
            val i0 = pos.toInt()
            val i1 = minOf(i0 + 1, frames - 1)
            val frac = (pos - i0).toFloat()
            val v = mono[i0] * (1f - frac) + mono[i1] * frac
            out[i] = (if (v > 32767f) 32767 else if (v < -32768f) -32768 else v.toInt()).toShort()
        }
        return out
    }
}
