package np.soundbox.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.util.concurrent.Executors

/**
 * "Fast mode": the voice engine makes short clips (numbers, "hundred", "rupees received"...) ONCE
 * and stores them on the phone. A payment is then announced by joining those clips and playing
 * them straight away, with no engine delay. Works for Hindi and English; other cases use normal TTS.
 */
object FastVoice {
    private const val TAG = "Soundbox"

    val status = MutableStateFlow("")

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    private var gen = 0
    private var currentKey = ""
    private var vocab: List<String> = emptyList()
    private var pcm: Array<ShortArray?> = arrayOfNulls(0)
    private var dir: File? = null
    private var nextIdx = 0
    private var sampleRate = 0
    private var pendingId = ""
    private var currentLang = ""
    private var currentLabel = ""

    @Volatile
    private var ready = false

    private val HI = listOf(
        "एक",
        "दो",
        "तीन",
        "चार",
        "पाँच",
        "छह",
        "सात",
        "आठ",
        "नौ",
        "दस",
        "ग्यारह",
        "बारह",
        "तेरह",
        "चौदह",
        "पंद्रह",
        "सोलह",
        "सत्रह",
        "अठारह",
        "उन्नीस",
        "बीस",
        "इक्कीस",
        "बाईस",
        "तेईस",
        "चौबीस",
        "पच्चीस",
        "छब्बीस",
        "सत्ताईस",
        "अट्ठाईस",
        "उनतीस",
        "तीस",
        "इकतीस",
        "बत्तीस",
        "तैंतीस",
        "चौंतीस",
        "पैंतीस",
        "छत्तीस",
        "सैंतीस",
        "अड़तीस",
        "उनतालीस",
        "चालीस",
        "इकतालीस",
        "बयालीस",
        "तैंतालीस",
        "चवालीस",
        "पैंतालीस",
        "छियालीस",
        "सैंतालीस",
        "अड़तालीस",
        "उनचास",
        "पचास",
        "इक्यावन",
        "बावन",
        "तिरपन",
        "चौवन",
        "पचपन",
        "छप्पन",
        "सत्तावन",
        "अट्ठावन",
        "उनसठ",
        "साठ",
        "इकसठ",
        "बासठ",
        "तिरसठ",
        "चौंसठ",
        "पैंसठ",
        "छियासठ",
        "सड़सठ",
        "अड़सठ",
        "उनहत्तर",
        "सत्तर",
        "इकहत्तर",
        "बहत्तर",
        "तिहत्तर",
        "चौहत्तर",
        "पचहत्तर",
        "छिहत्तर",
        "सतहत्तर",
        "अठहत्तर",
        "उन्यासी",
        "अस्सी",
        "इक्यासी",
        "बयासी",
        "तिरासी",
        "चौरासी",
        "पचासी",
        "छियासी",
        "सत्तासी",
        "अट्ठासी",
        "नवासी",
        "नब्बे",
        "इक्यानवे",
        "बानवे",
        "तिरानवे",
        "चौरानवे",
        "पचानवे",
        "छियानवे",
        "सत्तानवे",
        "अट्ठानवे",
        "निन्यानवे"
    )

    private val EN_ONES = listOf(
        "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
        "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
        "eighteen", "nineteen"
    )
    private val EN_TENS = listOf("twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")

    private fun enWord(n: Int): String {
        if (n < 20) return EN_ONES[n - 1]
        val t = EN_TENS[n / 10 - 2]
        return if (n % 10 == 0) t else t + " " + EN_ONES[n % 10 - 1]
    }

    // Layout: 0 = start phrase, 1 = end phrase, 2 = hundred, 3 = thousand, 4 = lakh, 4+n = number n (1..99)
    private fun vocabFor(lang: String, label: String): List<String> {
        val v = ArrayList<String>()
        if (lang == "hi") {
            v.add(label + " में")
            v.add("रुपये प्राप्त हुए")
            v.add("सौ")
            v.add("हज़ार")
            v.add("लाख")
            v.addAll(HI)
        } else {
            v.add("Received")
            v.add("rupees in " + label)
            v.add("hundred")
            v.add("thousand")
            v.add("lakh")
            for (n in 1..99) v.add(enWord(n))
        }
        return v
    }

    private fun phraseIds(amount: Long): List<Int>? {
        if (amount < 1 || amount > 9_999_999L) return null
        val ids = ArrayList<Int>()
        ids.add(0)
        var n = amount
        val lakh = (n / 100000).toInt()
        n %= 100000
        val th = (n / 1000).toInt()
        n %= 1000
        val h = (n / 100).toInt()
        val r = (n % 100).toInt()
        if (lakh > 0) { ids.add(4 + lakh); ids.add(4) }
        if (th > 0) { ids.add(4 + th); ids.add(3) }
        if (h > 0) { ids.add(4 + h); ids.add(2) }
        if (r > 0) ids.add(4 + r)
        ids.add(1)
        return ids
    }

    /** Call on the main thread. Cheap when nothing changed. */
    fun refresh(ctx: Context) {
        if (!Prefs.fastMode) {
            ready = false
            currentKey = ""
            gen++
            status.value = "Fast mode is off"
            return
        }
        val used = SpeechManager.resolveLanguage() ?: return
        if (used != "hi" && used != "en") {
            ready = false
            currentKey = ""
            gen++
            status.value = "Fast mode works for Hindi and English (using normal voice now)"
            return
        }
        val voice = Prefs.voiceFor(used).ifEmpty { "default" }.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val label = Prefs.announceLabel.ifBlank { "QR" }
        val dirKey = used + "_" + voice
        val key = dirKey + "|" + label
        if (key == currentKey) return
        gen++
        currentKey = key
        ready = false
        sampleRate = 0
        vocab = vocabFor(used, label)
        currentLang = used
        currentLabel = label
        pcm = arrayOfNulls(vocab.size)
        val d = File(ctx.applicationContext.filesDir, "fast/" + dirKey)
        d.mkdirs()
        dir = d
        nextIdx = 0
        step(gen)
    }

    /** The clip that contains the spoken name depends on the label, so its file name includes it. */
    private fun clipFile(d: File, idx: Int): File {
        val labelIdx = if (currentLang == "hi") 0 else 1
        return if (idx == labelIdx) File(d, idx.toString() + "_" + currentLabel.hashCode() + ".wav")
        else File(d, idx.toString() + ".wav")
    }

    private fun step(g: Int) {
        if (g != gen) return
        val d = dir ?: return
        while (nextIdx < vocab.size) {
            val f = clipFile(d, nextIdx)
            if (f.exists() && load(nextIdx, f)) {
                nextIdx++
                continue
            }
            f.delete()
            val t = SpeechManager.engine()
            if (t == null) {
                status.value = "Fast voice: voice engine not ready"
                return
            }
            val id = "fast-" + g + "-" + nextIdx
            pendingId = id
            status.value = "Fast voice: preparing " + (nextIdx + 1) + "/" + vocab.size + " (one time only)"
            val r = t.synthesizeToFile(vocab[nextIdx], Bundle(), f, id)
            if (r != TextToSpeech.SUCCESS) {
                status.value = "Fast voice: could not prepare (using normal voice)"
            }
            return
        }
        ready = true
        status.value = "Fast voice ready \u2713"
    }

    /** Called from SpeechManager's progress listener (any thread). */
    fun onSynthDone(id: String, ok: Boolean) {
        main.post {
            if (id != pendingId || !id.startsWith("fast-" + gen + "-")) return@post
            if (!ok) {
                status.value = "Fast voice: could not prepare (using normal voice)"
                return@post
            }
            val d = dir ?: return@post
            val f = clipFile(d, nextIdx)
            if (!load(nextIdx, f)) {
                f.delete()
                status.value = "Fast voice: not supported by this voice (using normal voice)"
                return@post
            }
            nextIdx++
            step(gen)
        }
    }

    /** Returns true if the announcement was started with the pre-made clips. */
    fun play(amount: Long): Boolean {
        if (!ready || sampleRate == 0) return false
        val ids = phraseIds(amount) ?: return false
        val parts = ArrayList<ShortArray>()
        for (i in ids) {
            val p = pcm[i] ?: return false
            parts.add(p)
        }
        val rate = sampleRate
        exec.execute { playBlocking(parts, rate) }
        return true
    }

    private fun playBlocking(parts: List<ShortArray>, rate: Int) {
        try {
            val gap = rate / 25
            var total = 0
            for (p in parts) total += p.size
            total += gap * (parts.size - 1)
            val gain = Prefs.volume * (if (Prefs.boost) 2f else 1f)
            val buf = ShortArray(total)
            var pos = 0
            for ((i, p) in parts.withIndex()) {
                for (s in p) {
                    val v = (s * gain).toInt()
                    buf[pos++] = (if (v > 32767) 32767 else if (v < -32768) -32768 else v).toShort()
                }
                if (i < parts.size - 1) pos += gap
            }
            if (Prefs.maxVolume) SpeechManager.raiseVolume()
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buf.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(buf, 0, buf.size)
            track.play()
            Thread.sleep(total * 1000L / rate + 250L)
            track.stop()
            track.release()
        } catch (e: Exception) {
            Log.w(TAG, "Fast playback failed", e)
        }
    }

    // ---------- WAV helpers ----------

    private class Wav(val rate: Int, val channels: Int, val pcm: ShortArray)

    private fun parseWav(b: ByteArray): Wav? {
        if (b.size < 44) return null
        fun u16(o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
        fun u32(o: Int): Int = u16(o) or (u16(o + 2) shl 16)
        if (String(b, 0, 4, Charsets.US_ASCII) != "RIFF") return null
        var o = 12
        var rate = 0
        var ch = 0
        var bits = 0
        while (o + 8 <= b.size) {
            val id = String(b, o, 4, Charsets.US_ASCII)
            var size = u32(o + 4)
            val start = o + 8
            if (id == "fmt ") {
                ch = u16(start + 2)
                rate = u32(start + 4)
                bits = u16(start + 14)
            } else if (id == "data") {
                if (size < 0 || start + size > b.size) size = b.size - start
                if (bits != 16 || ch <= 0 || rate <= 0) return null
                val n = size / 2
                val s = ShortArray(n)
                for (i in 0 until n) s[i] = u16(start + 2 * i).toShort()
                return Wav(rate, ch, s)
            }
            if (size < 0) return null
            o = start + size + (size and 1)
        }
        return null
    }

    private fun trim(s: ShortArray, rate: Int): ShortArray {
        var first = -1
        var last = -1
        for (i in s.indices) {
            if (Math.abs(s[i].toInt()) > 500) {
                if (first < 0) first = i
                last = i
            }
        }
        if (first < 0) return ShortArray(0)
        val pad = rate / 50
        val a = maxOf(0, first - pad)
        val e = minOf(s.size, last + pad)
        return s.copyOfRange(a, e)
    }

    private fun load(idx: Int, f: File): Boolean {
        return try {
            val w = parseWav(f.readBytes())
            if (w == null || w.channels != 1) {
                false
            } else {
                if (sampleRate == 0) sampleRate = w.rate
                if (w.rate != sampleRate) {
                    false
                } else {
                    val t = trim(w.pcm, w.rate)
                    if (t.isEmpty()) {
                        false
                    } else {
                        pcm[idx] = t
                        true
                    }
                }
            }
        } catch (e: Exception) {
            false
        }
    }
}
