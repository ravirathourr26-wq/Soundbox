package np.soundbox.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SbCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun Hero(
    colors: List<Color> = listOf(Brand.Green, Brand.GreenDark),
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(colors))
            .padding(24.dp),
        content = content
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(),
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        color = Brand.Muted,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp)
    )
}

@Composable
fun SbButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    enabled: Boolean = true
) {
    val m = modifier
        .fillMaxWidth()
        .height(52.dp)
    if (filled) {
        Button(
            onClick = onClick,
            enabled = enabled,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Brand.Green, contentColor = Color.White),
            modifier = m
        ) { Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
    } else {
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, Brand.Line),
            modifier = m
        ) { Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Brand.Green) }
    }
}

@Composable
fun SmallButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Brand.GreenLight)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Brand.Green)
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Brand.Ink)
            if (subtitle.isNotEmpty()) Text(subtitle, fontSize = 13.sp, color = Brand.Muted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Brand.Green, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun StatusRow(title: String, status: String, ok: Boolean, action: String, onAction: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Brand.Ink)
            Text(status, fontSize = 13.sp, color = if (ok) Brand.Green else Brand.Warn)
        }
        SmallButton(action, onAction)
    }
}

@Composable
fun RowDivider() {
    HorizontalDivider(color = Brand.Line)
}

@Composable
fun BottomBar(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.background(Color.White)) {
        HorizontalDivider(color = Brand.Line)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            labels.forEachIndexed { i, label ->
                val sel = i == selected
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (sel) Brand.GreenLight else Color.Transparent)
                        .clickable { onSelect(i) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        fontSize = 15.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                        color = if (sel) Brand.Green else Brand.Muted,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun SpeakerIcon(color: Color, iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val w = this.size.width
        val h = this.size.height
        val body = Path()
        body.moveTo(0.08f * w, 0.38f * h)
        body.lineTo(0.28f * w, 0.38f * h)
        body.lineTo(0.52f * w, 0.16f * h)
        body.lineTo(0.52f * w, 0.84f * h)
        body.lineTo(0.28f * w, 0.62f * h)
        body.lineTo(0.08f * w, 0.62f * h)
        body.close()
        drawPath(body, color)
        drawArc(
            color = color,
            startAngle = -45f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(0.4f * w, 0.3f * h),
            size = Size(0.4f * w, 0.4f * h),
            style = Stroke(width = 0.07f * w, cap = StrokeCap.Round)
        )
        drawArc(
            color = color,
            startAngle = -45f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(0.28f * w, 0.16f * h),
            size = Size(0.64f * w, 0.68f * h),
            style = Stroke(width = 0.07f * w, cap = StrokeCap.Round)
        )
    }
}

/** App logo: a scan frame ("capture") with sound bars inside. */
@Composable
fun CaptureIcon(color: Color, iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val w = this.size.width
        val sw = 0.075f * w
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
            drawLine(color, Offset(x1 * w, y1 * w), Offset(x2 * w, y2 * w), strokeWidth = sw, cap = StrokeCap.Round)
        }
        val a = 0.14f
        val b = 0.86f
        val c = 0.34f
        val e = 0.66f
        line(a, a, a, c)
        line(a, a, c, a)
        line(b, a, b, c)
        line(b, a, e, a)
        line(a, b, a, e)
        line(a, b, c, b)
        line(b, b, b, e)
        line(b, b, e, b)
        line(0.36f, 0.42f, 0.36f, 0.58f)
        line(0.5f, 0.32f, 0.5f, 0.68f)
        line(0.64f, 0.42f, 0.64f, 0.58f)
    }
}
