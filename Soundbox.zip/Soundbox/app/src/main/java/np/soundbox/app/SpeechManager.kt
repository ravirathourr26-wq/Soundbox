package np.soundbox.app

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

/**
 * Wraps TextToSpeech. Uses QUEUE_ADD so several payments are spoken one after another.
 * Must be used from the main thread (service callbacks and UI both are).
 */
object SpeechManager {
    private const val TAG = "Soundbox"

    private var tts: TextToSpeech? = null
    private var ready = false
    private var appCtx: Context? = null
    private var counter = 0
    private var failCount = 0
    private val pending = ArrayDeque<String>()

    private val names = mapOf("ne" to "Nepali", "hi" to "Hindi", "en" to "English")

    /** Human readable info about the last utterance, shown on the Home screen. */
    val lastSpoken = MutableStateFlow("")

    fun init(context: Context) {
        if (tts != null) return
        val app = context.applicationContext
        appCtx = app
        ready = false
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                ready = true
                while (ready && pending.isNotEmpty()) speakNow(pending.removeFirst())
            } else {
                Log.e(TAG, "TextToSpeech init failed: $status")
                lastSpoken.value = "Text-to-speech engine is not available on this phone"
                tts = null
                ready = false
            }
        }
    }

    fun speakAmount(amountText: String) {
        if (tts == null) appCtx?.let { init(it) }
        if (!ready) {
            pending.addLast(amountText)
            return
        }
        speakNow(amountText)
    }

    private fun localeFor(code: String): Locale = when (code) {
        "ne" -> Locale("ne", "NP")
        "hi" -> Locale("hi", "IN")
        else -> Locale.ENGLISH
    }

    private fun restart() {
        try { tts?.shutdown() } catch (e: Exception) { }
        tts = null
        ready = false
        appCtx?.let { init(it) }
    }

    private fun speakNow(amount: String) {
        val t = tts ?: return
        if (!ready) {
            pending.addFirst(amount)
            return
        }
        val candidates = when (Prefs.language) {
            "ne" -> listOf("ne", "hi", "en")
            "hi" -> listOf("hi", "en")
            else -> listOf("en")
        }
        var used = "en"
        for (c in candidates) {
            val r = t.setLanguage(localeFor(c))
            if (r >= TextToSpeech.LANG_AVAILABLE) {
                used = c
                break
            }
        }
        val text = when (used) {
            "ne" -> "eSewa मा $amount रुपैयाँ प्राप्त भयो"
            "hi" -> "eSewa में $amount रुपये प्राप्त हुए"
            else -> "Received $amount rupees in eSewa"
        }
        val params = Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Prefs.volume)
        val r = t.speak(text, TextToSpeech.QUEUE_ADD, params, "sb-${counter++}")
        if (r != TextToSpeech.SUCCESS) {
            Log.w(TAG, "speak failed: $r")
            if (failCount < 3) {
                failCount++
                pending.addFirst(amount)
                restart()
            } else {
                failCount = 0
                lastSpoken.value = "Could not speak (voice engine error)"
            }
            return
        }
        failCount = 0

        val wanted = candidates.first()
        lastSpoken.value = if (used == wanted) {
            "Spoke in ${names[used]}"
        } else {
            "Spoke in ${names[used]} (${names[wanted]} voice not installed)"
        }
    }
}
