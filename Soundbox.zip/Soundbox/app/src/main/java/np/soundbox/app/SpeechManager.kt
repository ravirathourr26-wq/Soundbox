package np.soundbox.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Bundle
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

/**
 * Wraps TextToSpeech. Uses QUEUE_ADD so several payments are spoken one after another.
 * Must be used from the main thread (service callbacks and UI both are).
 */
object SpeechManager {
    private const val TAG = "Payment Speaker"

    private var tts: TextToSpeech? = null
    private var ready = false
    private var appCtx: Context? = null
    private var counter = 0
    private var failCount = 0
    private var initStartedAt = 0L
    private val starts = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private var cacheLang = ""
    private var cacheUsed = "en"
    private var cacheVoice = "?"
    private var sessionId = 0
    private var enhancer: LoudnessEnhancer? = null
    private val pending = ArrayDeque<String>()

    private val names = mapOf("ne" to "Nepali", "hi" to "Hindi", "en" to "English")

    /** Human readable info about the last utterance, shown on the Home screen. */
    val lastSpoken = MutableStateFlow("")

    /** How long the voice engine took to start speaking the last announcement. */
    val lastLatency = MutableStateFlow("")

    /** Result of the last automatic volume change (shown in Logs). */
    val volumeInfo = MutableStateFlow("")

    /** Language the phone voice really uses (may differ from the choice if that voice is missing). */
    val activeLang = MutableStateFlow("")

    fun init(context: Context) {
        if (tts != null) return
        val app = context.applicationContext
        appCtx = app
        ready = false
        initStartedAt = SystemClock.elapsedRealtime()
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        if (utteranceId == null) return
                        val t0 = starts.remove(utteranceId) ?: return
                        lastLatency.value = "Voice started after ${SystemClock.elapsedRealtime() - t0} ms"
                    }

                    override fun onDone(utteranceId: String?) {
                        if (utteranceId != null && utteranceId.startsWith("fast-")) {
                            FastVoice.onSynthDone(utteranceId, true)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (utteranceId != null && utteranceId.startsWith("fast-")) {
                            FastVoice.onSynthDone(utteranceId, false)
                        }
                    }
                })
                setupBoost()
                ready = true
                FastVoice.refresh(app)
                while (ready && pending.isNotEmpty()) speakNow(pending.removeFirst())
            } else {
                Log.e(TAG, "TextToSpeech init failed: $status")
                lastSpoken.value = "Text-to-speech engine is not available on this phone"
                tts = null
                ready = false
            }
        }
    }

    fun speakAmount(amountText: String) {
        val whole = amountText.toLongOrNull()
        if (whole != null && FastVoice.playBundled(whole)) {
            lastSpoken.value = "Spoke instantly (recorded voice)"
            lastLatency.value = "Fast mode: recorded voice, no engine delay"
            return
        }
        if (tts == null) appCtx?.let { init(it) }
        appCtx?.let { FastVoice.refresh(it) }
        if (Prefs.fastMode && whole != null && FastVoice.playOrQueue(whole)) {
            lastSpoken.value = "Spoke instantly in " + langLabel(activeLang.value.ifEmpty { "hi" }) + " (fast mode)"
            lastLatency.value = "Fast mode: pre-made voice, no engine delay"
            return
        }
        if (!ready && tts != null && SystemClock.elapsedRealtime() - initStartedAt > 4000) restart()
        if (!ready) {
            pending.addLast(amountText)
            return
        }
        speakNow(amountText)
    }

    private fun localeFor(code: String): Locale = when (code) {
        "ne" -> Locale("ne", "NP")
        "hi" -> Locale("hi", "IN")
        else -> Locale.ENGLISH
    }

    /** Installed voices for a language ("ne", "hi", "en"), for the voice picker. */
    fun availableVoices(lang: String): List<Voice> {
        val t = tts ?: return emptyList()
        return try {
            val code = localeFor(lang).language
            (t.voices ?: emptySet<Voice>())
                .filter { it.locale.language == code }
                .filter { !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) }
                .sortedBy { it.name }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Sets language/voice only when it actually changed, so the engine is not reloaded every time. */
    /** Voices of this language that are really installed on the phone. */
    private fun installedVoices(t: TextToSpeech, code: String): List<Voice> {
        return try {
            val lang = localeFor(code).language
            (t.voices ?: emptySet<Voice>())
                .filter { it.locale.language == lang }
                .filter { !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Offline voices first, then the best quality, then the fastest. */
    private fun bestVoice(t: TextToSpeech, code: String): Voice? {
        val list = installedVoices(t, code)
        if (list.isEmpty()) return null
        return list.sortedWith(
            compareBy<Voice>({ it.isNetworkConnectionRequired }, { -it.quality }, { it.latency })
        ).first()
    }

    /** True if a voice for this language is really there (when the engine tells us). */
    private fun languageUsable(t: TextToSpeech, code: String): Boolean {
        val all = try {
            t.voices
        } catch (e: Exception) {
            null
        }
        if (all == null || all.isEmpty()) return true
        return installedVoices(t, code).isNotEmpty()
    }

    private fun prepareVoice(t: TextToSpeech, candidates: List<String>): String {
        val pref = Prefs.language
        if (pref != cacheLang) {
            var used = "en"
            for (c in candidates) {
                val r = t.setLanguage(localeFor(c))
                if (r >= TextToSpeech.LANG_AVAILABLE && languageUsable(t, c)) {
                    used = c
                    break
                }
            }
            cacheUsed = used
            cacheLang = pref
            cacheVoice = "?"
        }
        val sv = Prefs.voiceFor(cacheUsed)
        if (sv != cacheVoice) {
            t.setLanguage(localeFor(cacheUsed))
            try {
                val v = if (sv.isNotEmpty()) t.voices?.firstOrNull { it.name == sv } else bestVoice(t, cacheUsed)
                if (v != null) t.setVoice(v)
            } catch (e: Exception) {
                Log.w(TAG, "setVoice failed", e)
            }
            cacheVoice = sv
        }
        activeLang.value = cacheUsed
        return cacheUsed
    }

    /** Language that will actually be spoken (also applies it to the engine). Null if engine not ready. */
    fun resolveLanguage(): String? {
        val t = tts ?: return null
        if (!ready) return null
        val candidates = when (Prefs.language) {
            "ne" -> listOf("ne", "hi", "en")
            "hi" -> listOf("hi", "en")
            else -> listOf("en")
        }
        return prepareVoice(t, candidates)
    }

    fun engine(): TextToSpeech? = if (ready) tts else null

    /** Keeps the voice engine connected and awake (best effort). */
    fun warmUp() {
        val t = tts ?: return
        if (!ready) return
        try {
            if (!t.isSpeaking) {
                t.playSilentUtterance(1L, TextToSpeech.QUEUE_ADD, "warm-${counter++}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "warmUp failed", e)
        }
    }

    private fun setupBoost() {
        val ctx = appCtx ?: return
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (sessionId == 0) sessionId = am.generateAudioSessionId()
            enhancer?.release()
            val le = LoudnessEnhancer(sessionId)
            le.setTargetGain(500)
            le.setEnabled(true)
            enhancer = le
        } catch (e: Exception) {
            Log.w(TAG, "Loudness boost not available", e)
            enhancer = null
        }
    }

    fun raiseVolume() {
        val ctx = appCtx ?: return
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val stream = if (Prefs.alarmChannel) AudioManager.STREAM_ALARM else AudioManager.STREAM_MUSIC
            val max = am.getStreamMaxVolume(stream)
            try {
                am.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0)
            } catch (e: Exception) {
            }
            am.setStreamVolume(stream, max, 0)
            var now = am.getStreamVolume(stream)
            if (now < max) {
                // Some phones ignore the first call: step the volume up instead.
                for (k in 0 until max) {
                    am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, 0)
                }
                now = am.getStreamVolume(stream)
            }
            volumeInfo.value = "Volume " + now + "/" + max + " at " + fmtTime(System.currentTimeMillis())
        } catch (e: Exception) {
            volumeInfo.value = "Could not change volume: " + (e.message ?: e.javaClass.simpleName)
            Log.w(TAG, "Could not raise volume", e)
        }
    }

    private fun restart() {
        cacheLang = ""
        try { enhancer?.release() } catch (e: Exception) { }
        enhancer = null
        try { tts?.shutdown() } catch (e: Exception) { }
        tts = null
        ready = false
        appCtx?.let { init(it) }
    }

    private fun speakNow(amount: String) {
        val t = tts ?: return
        if (!ready) {
            pending.addFirst(amount)
            return
        }
        val candidates = when (Prefs.language) {
            "ne" -> listOf("ne", "hi", "en")
            "hi" -> listOf("hi", "en")
            else -> listOf("en")
        }
        val used = prepareVoice(t, candidates)
        val label = Prefs.announceLabel.ifBlank { "QR" }
        val text = when (used) {
            "ne" -> "$label मा $amount रुपैयाँ प्राप्त भयो"
            "hi" -> "$label में $amount रुपये प्राप्त हुए"
            else -> "Received $amount rupees in $label"
        }
        try {
            t.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(if (Prefs.alarmChannel) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
        } catch (e: Exception) {
        }
        val params = Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Prefs.volume)
        if (Prefs.boost && enhancer != null && sessionId != 0) {
            params.putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, sessionId)
        }
        if (Prefs.maxVolume) raiseVolume()
        val id = "sb-${counter++}"
        starts[id] = SystemClock.elapsedRealtime()
        val r = t.speak(text, TextToSpeech.QUEUE_ADD, params, id)
        if (r != TextToSpeech.SUCCESS) {
            Log.w(TAG, "speak failed: $r")
            if (failCount < 3) {
                failCount++
                pending.addFirst(amount)
                restart()
            } else {
                failCount = 0
                lastSpoken.value = "Could not speak (voice engine error)"
            }
            return
        }
        failCount = 0

        val wanted = candidates.first()
        lastSpoken.value = if (used == wanted) {
            "Spoke in ${names[used]}"
        } else {
            "Spoke in ${names[used]} (${names[wanted]} voice not installed)"
        }
    }
}
