package np.soundbox.app

import android.app.Application

class SoundboxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        FastVoice.restoreFromDisk(this)
        FastVoice.loadBundled(this)
        SpeechManager.init(this)
    }
}
