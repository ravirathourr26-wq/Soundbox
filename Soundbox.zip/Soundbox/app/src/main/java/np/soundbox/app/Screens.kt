package np.soundbox.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay

// ---------- Shell with bottom bar ----------

@Composable
fun MainShell(tick: Int) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Brand.Bg,
        bottomBar = { BottomBar(listOf("Home", "History", "Capture", "Settings"), tab) { tab = it } }
    ) { pad ->
        Box(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            when (tab) {
                0 -> HomeScreen(tick)
                1 -> HistoryScreen()
                2 -> DebugScreen()
                else -> SettingsScreen(tick)
            }
        }
    }
}

@Composable
private fun LangChip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) Brand.Green else Color(0xFFF0F3F1))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (selected) Color.White else Brand.Ink,
            maxLines = 1
        )
    }
}

// ---------- Home ----------

@Composable
fun HomeScreen(tick: Int) {
    val ctx = LocalContext.current
    val enabled = remember(tick) { isListenerEnabled(ctx) }
    var volume by remember { mutableFloatStateOf(Prefs.volume) }
    var lang by remember { mutableStateOf(Prefs.language) }
    val spoken by SpeechManager.lastSpoken.collectAsState()
    val payments by Store.payments.collectAsState()
    val active by SpeechManager.activeLang.collectAsState()
    val preparing by FastVoice.preparing.collectAsState()
    val prog by FastVoice.progress.collectAsState()
    val fastReady by FastVoice.isReady.collectAsState()
    val fastStatus by FastVoice.status.collectAsState()
    // Nepali recorded clips are inside the app, so the phone needs no Nepali voice
    val nepaliRecorded = lang == "ne" && (fastReady || fastStatus.isNotEmpty()) && FastVoice.usingRecordedNepali()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(46.dp)
                    .background(Brand.GreenLight, CircleShape),
                contentAlignment = Alignment.Center
            ) { SpeakerIcon(Brand.Green, 28.dp) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Payment Speaker", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Brand.Ink)
                Text("Payment announcer", fontSize = 13.sp, color = Brand.Muted)
            }
        }

        val pulse = rememberInfiniteTransition()
        val dotAlpha by pulse.animateFloat(
            initialValue = 0.35f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(animation = tween(900), repeatMode = RepeatMode.Reverse)
        )
        val todayStart = remember(payments) { startOfToday() }
        val todayList = payments.filter { it.time >= todayStart }
        val todayTotal = todayList.fold(0.0) { acc, p -> acc + p.amount }
        val last = payments.firstOrNull()

        Hero(
            colors = if (enabled) listOf(Brand.Green, Brand.GreenDark)
            else listOf(Color(0xFFB3261E), Color(0xFF8C1D18))
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(10.dp)
                        .alpha(if (enabled) dotAlpha else 1f)
                        .background(if (enabled) Color(0xFF7CFFB2) else Color(0xFFFFB4A9), CircleShape)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (enabled) "LISTENING" else "OFF",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.85f),
                    letterSpacing = 1.sp
                )
            }
            Spacer(Modifier.height(14.dp))
            if (enabled) {
                Text(
                    "TODAY'S COLLECTION",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.8f),
                    letterSpacing = 1.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Rs ${AmountParser.pretty(todayTotal)}",
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (last == null) "No payments yet"
                    else "${todayList.size} payment(s) today  ·  Last: Rs ${AmountParser.pretty(last.amount)}, ${timeAgo(last.time)}",
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
            } else {
                Text(
                    "Notification access is off",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Open Settings > Permissions to turn it on.",
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }

        HealthCard(tick)

        SbCard {
            Text("Voice", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Brand.Ink)
            Spacer(Modifier.height(14.dp))
            Text("Language", fontSize = 13.sp, color = Brand.Muted)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ne" to "नेपाली", "hi" to "हिन्दी", "en" to "English").forEach { (code, label) ->
                    LangChip(label, lang == code, Modifier.weight(1f)) {
                        lang = code
                        Prefs.language = code
                        FastVoice.refresh(ctx)
                    }
                }
            }
            if (active.isNotEmpty() && active != lang && !nepaliRecorded) {
                Spacer(Modifier.height(10.dp))
                Text(
                    langLabel(lang) + " voice is not available on this phone, so " + langLabel(active) + " is used.",
                    fontSize = 13.sp,
                    color = Brand.Warn
                )
                if (active == "en") {
                    Spacer(Modifier.height(6.dp))
                    SmallButton("Install voice") { openVoiceInstall(ctx) }
                }
            }
            Spacer(Modifier.height(16.dp))
            SbButton("Test voice", { SpeechManager.speakAmount("500") })
            if (preparing) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "Preparing the faster voice... " + (prog * 100).toInt() + "%. Announcements work meanwhile.",
                    fontSize = 13.sp,
                    color = Brand.Muted
                )
            }
            if (spoken.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(spoken, fontSize = 13.sp, color = Brand.Muted)
            }
        }

        SbCard {
            Text("Volume", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Brand.Ink)
            Slider(
                value = volume,
                onValueChange = { volume = it; Prefs.volume = it },
                valueRange = 0.1f..1f,
                colors = SliderDefaults.colors(
                    thumbColor = Brand.Green,
                    activeTrackColor = Brand.Green,
                    inactiveTrackColor = Brand.Line
                )
            )
            Text("Tip: keep the phone's media volume high.", fontSize = 13.sp, color = Brand.Muted)
        }
    }

}

// ---------- History ----------

@Composable
fun HistoryScreen() {
    val list by Store.payments.collectAsState()
    val start = remember(list) { startOfToday() }
    val today = list.filter { it.time >= start }
    val total = today.fold(0.0) { acc, p -> acc + p.amount }
    var confirm by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text("History", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Brand.Ink)
        Spacer(Modifier.height(12.dp))
        Hero {
            Text(
                "TODAY'S TOTAL",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.85f),
                letterSpacing = 1.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Rs ${AmountParser.pretty(total)}",
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(Modifier.height(4.dp))
            Text("${today.size} payment(s)", fontSize = 14.sp, color = Color.White.copy(alpha = 0.8f))
        }
        if (today.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            SbButton(
                "Share today's report",
                {
                    val sb = StringBuilder()
                    sb.append("Payment Speaker - ").append(fmtDate(System.currentTimeMillis())).append("\n")
                    sb.append("Total: Rs ").append(AmountParser.pretty(total))
                        .append(" (").append(today.size).append(" payments)\n\n")
                    for (p in today.reversed()) {
                        sb.append(fmtTime(p.time)).append("  Rs ").append(AmountParser.pretty(p.amount))
                            .append("  ").append(sourceName(p.pkg)).append("\n")
                    }
                    val send = Intent(Intent.ACTION_SEND)
                    send.type = "text/plain"
                    send.putExtra(Intent.EXTRA_TEXT, sb.toString())
                    ctx.startActivity(Intent.createChooser(send, "Share report"))
                },
                filled = false
            )
        }
        Spacer(Modifier.height(8.dp))
        if (list.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { confirm = true }) {
                    Text("Clear history", color = Brand.Bad, fontWeight = FontWeight.SemiBold)
                }
            }
        } else {
            Text(
                "No payments yet. They will appear here.",
                fontSize = 15.sp,
                color = Brand.Muted,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { p ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Rs ${AmountParser.pretty(p.amount)}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Brand.Ink
                        )
                        Text(sourceName(p.pkg), fontSize = 13.sp, color = Brand.Muted)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(fmtTime(p.time), fontSize = 14.sp, color = Brand.Ink)
                        Text(fmtDate(p.time), fontSize = 12.sp, color = Brand.Muted)
                    }
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = Color.White,
            title = { Text("Clear history?") },
            text = { Text("All saved payments will be deleted from this phone.") },
            confirmButton = {
                TextButton(onClick = { Store.clearPayments(); confirm = false }) {
                    Text("Clear", color = Brand.Bad)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Cancel", color = Brand.Muted) }
            }
        )
    }
}

// ---------- Logs (debug) ----------

@Composable
fun DebugScreen() {
    val ctx = LocalContext.current
    val list by Store.debug.collectAsState()
    var on by remember { mutableStateOf(Prefs.debugEnabled) }
    val decision by Store.lastDecision.collectAsState()
    val latency by SpeechManager.lastLatency.collectAsState()
    val fastStatus by FastVoice.status.collectAsState()
    val volumeInfo by SpeechManager.volumeInfo.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text("Capture", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Brand.Ink)
        Spacer(Modifier.height(12.dp))
        SbCard {
            Text("Last payment result", fontSize = 13.sp, color = Brand.Muted)
            Text(
                if (decision.isEmpty()) "None yet" else decision,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = Brand.Ink
            )
            if (latency.isNotEmpty()) Text(latency, fontSize = 13.sp, color = Brand.Muted)
            if (fastStatus.isNotEmpty()) Text(fastStatus, fontSize = 13.sp, color = Brand.Muted)
            if (volumeInfo.isNotEmpty()) Text(volumeInfo, fontSize = 13.sp, color = Brand.Muted)
            Spacer(Modifier.height(6.dp))
            SwitchRow("Capture notifications", "Keeps the last 50 notifications from all apps", on) {
                on = it
                Prefs.debugEnabled = it
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SbButton(
                "Copy all",
                {
                    val txt = list.joinToString("\n\n") {
                        "[${fmtDate(it.time)} ${fmtTime(it.time)}]\npackage: ${it.pkg}\ntitle: ${it.title}\ntext: ${it.text}"
                    }
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Payment Speaker log", txt))
                    Toast.makeText(ctx, "Copied ${list.size} entries", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f),
                enabled = list.isNotEmpty()
            )
            SbButton(
                "Clear",
                { Store.clearDebug() },
                modifier = Modifier.weight(1f),
                filled = false,
                enabled = list.isNotEmpty()
            )
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) {
            Text(
                "Nothing captured yet. Keep Notification Access on and the switch above enabled.",
                fontSize = 14.sp,
                color = Brand.Muted
            )
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { e ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .padding(14.dp)
                ) {
                    Text("${fmtTime(e.time)}  •  ${e.pkg}", fontSize = 12.sp, color = Brand.Green)
                    Text(e.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Brand.Ink)
                    Text(e.text, fontSize = 14.sp, color = Brand.Muted)
                }
            }
        }
    }
}

// ---------- Settings ----------

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Brand.Green,
    focusedLabelColor = Brand.Green,
    cursorColor = Brand.Green
)

@Composable
fun SettingsScreen(tick: Int) {
    val ctx = LocalContext.current
    var all by remember { mutableStateOf(Prefs.allApps) }
    var lbl by remember { mutableStateOf(Prefs.announceLabel) }
    var pk by remember { mutableStateOf(Prefs.packagesText) }
    var kw by remember { mutableStateOf(Prefs.keywordsText) }
    var fm by remember { mutableStateOf(Prefs.fastMode) }
    var mx by remember { mutableStateOf(Prefs.maxVolume) }
    var al by remember { mutableStateOf(Prefs.alarmChannel) }
    var bo by remember { mutableStateOf(Prefs.boost) }
    var ka by remember { mutableStateOf(Prefs.keepAlive) }
    var boot by remember { mutableStateOf(Prefs.autoStart) }
    var running by remember { mutableStateOf(false) }
    LaunchedEffect(tick) {
        while (true) {
            running = KeepAliveService.isRunning(ctx)
            delay(1500)
        }
    }
    val listenerOn = remember(tick) { isListenerEnabled(ctx) }
    val notifOn = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val batteryOk = remember(tick) { isIgnoringBattery(ctx) }
    val keepErr by KeepAliveService.lastError.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Brand.Ink)

        SectionLabel("Detection")
        SbCard {
            SwitchRow(
                "Capture all payment apps",
                "eSewa, Khalti, IME Pay, banks, SMS and more",
                all
            ) { all = it; Prefs.allApps = it }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = lbl,
                onValueChange = { lbl = it; Prefs.announceLabel = it },
                label = { Text("Spoken name (e.g. QR, eSewa)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
        }

        SectionLabel("Voice")
        SbCard {
            SwitchRow("Fast voice mode", "Instant announcements (Nepali recorded voice, Hindi & English)", fm) {
                fm = it
                Prefs.fastMode = it
                FastVoice.refresh(ctx)
            }
            RowDivider()
            SwitchRow("Maximum volume", "Raise phone volume to full when a payment arrives", mx) {
                mx = it
                Prefs.maxVolume = it
            }
            RowDivider()
            SwitchRow("Alarm sound channel", "Louder and works in silent mode. Use if the volume does not rise.", al) {
                al = it
                Prefs.alarmChannel = it
            }
            RowDivider()
            SwitchRow("Loudness boost", "Adds extra +10 dB to the voice", bo) {
                bo = it
                Prefs.boost = it
            }
        }

        SectionLabel("Background")
        SbCard {
            SwitchRow("Keep running", "Shows a small notification so Android keeps Payment Speaker alive", ka) {
                ka = it
                Prefs.keepAlive = it
                if (it) KeepAliveService.start(ctx) else KeepAliveService.stop(ctx)
            }
            RowDivider()
            SwitchRow("Start after phone restart", "", boot) { boot = it; Prefs.autoStart = it }
        }

        SectionLabel("Permissions")
        SbCard {
            StatusRow(
                "Notification access",
                if (listenerOn) "Allowed" else "Not allowed",
                listenerOn,
                "Manage"
            ) { openNotificationAccessSettings(ctx) }
            RowDivider()
            StatusRow(
                "Notifications",
                if (notifOn) "Allowed" else "Blocked",
                notifOn,
                "Manage"
            ) { openAppNotificationSettings(ctx) }
            RowDivider()
            StatusRow(
                "Battery",
                if (batteryOk) "Unrestricted" else "Restricted",
                batteryOk,
                if (batteryOk) "Manage" else "Allow"
            ) { requestBatteryExemption(ctx) }
            RowDivider()
            StatusRow(
                "Background service",
                if (running) "Running" else if (keepErr.isNotEmpty()) "Error: $keepErr" else "Not running",
                running,
                "Start"
            ) {
                Prefs.keepAlive = true
                ka = true
                KeepAliveService.start(ctx)
            }
        }

        SectionLabel("Advanced")
        SbCard {
            OutlinedTextField(
                value = pk,
                onValueChange = { pk = it; Prefs.packagesText = it },
                label = { Text("Always-listen apps (package names)") },
                minLines = 2,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = kw,
                onValueChange = { kw = it; Prefs.keywordsText = it },
                label = { Text("\"Received\" keywords (comma separated)") },
                minLines = 2,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Messages containing sent / paid / debited / failed are always ignored.",
                fontSize = 13.sp,
                color = Brand.Muted
            )
            Spacer(Modifier.height(12.dp))
            SbButton(
                "Reset to defaults",
                {
                    pk = Prefs.DEFAULT_PACKAGES
                    kw = Prefs.DEFAULT_KEYWORDS
                    Prefs.packagesText = pk
                    Prefs.keywordsText = kw
                },
                filled = false
            )
        }

        SectionLabel("Please note")
        SbCard {
            Text(
                "Announcements depend on phone notifications, which can be delayed, missed or even faked. For large amounts, always confirm the payment in the eSewa, Khalti or bank app before handing over goods. Payment Speaker is not affiliated with eSewa, Khalti or any bank.",
                fontSize = 13.sp,
                color = Brand.Muted
            )
        }

        Text(
            "Payment Speaker v${appVersion(ctx)}  ·  Works offline  ·  No data leaves this phone",
            fontSize = 12.sp,
            color = Brand.Muted,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        )
    }
}

/** One-glance check on the Home screen: everything fine, or what to fix. */
@Composable
fun HealthCard(tick: Int) {
    val ctx = LocalContext.current
    val listenerOn = remember(tick) { isListenerEnabled(ctx) }
    val notifOn = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val batteryOk = remember(tick) { isIgnoringBattery(ctx) }
    var running by remember { mutableStateOf(true) }
    LaunchedEffect(tick) {
        while (true) {
            running = !Prefs.keepAlive || KeepAliveService.isRunning(ctx)
            delay(2000)
        }
    }
    val allGood = listenerOn && notifOn && batteryOk && running
    if (allGood) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(8.dp)
                    .background(Brand.Green, CircleShape)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "All set. Ready to announce payments.",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Brand.Green
            )
        }
    } else {
        SbCard {
            Text("Needs attention", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Brand.Warn)
            if (!listenerOn) {
                StatusRow("Notification access", "Off - payments cannot be detected", false, "Fix") {
                    openNotificationAccessSettings(ctx)
                }
            }
            if (!notifOn) {
                StatusRow("Notifications", "Blocked for this app", false, "Fix") {
                    openAppNotificationSettings(ctx)
                }
            }
            if (!batteryOk) {
                StatusRow("Battery", "Restricted - the phone may stop the app", false, "Fix") {
                    requestBatteryExemption(ctx)
                }
            }
            if (!running) {
                StatusRow("Background service", "Not running", false, "Start") {
                    KeepAliveService.start(ctx)
                }
            }
        }
    }
}
