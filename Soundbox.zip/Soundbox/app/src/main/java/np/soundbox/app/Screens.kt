package np.soundbox.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- helpers ----------

private fun isListenerEnabled(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

private fun isIgnoringBattery(ctx: Context): Boolean {
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    return pm.isIgnoringBatteryOptimizations(ctx.packageName)
}

private fun requestBatteryExemption(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
        )
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e2: Exception) {
            Toast.makeText(ctx, "Open Settings > Battery manually", Toast.LENGTH_LONG).show()
        }
    }
}

private fun startOfToday(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

private fun fmtTime(t: Long): String = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(t))
private fun fmtDate(t: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(t))

// ---------- Home ----------

@Composable
fun HomeScreen(tick: Int) {
    val ctx = LocalContext.current
    val enabled = remember(tick) { isListenerEnabled(ctx) }
    val batteryOk = remember(tick) { isIgnoringBattery(ctx) }
    var volume by remember { mutableFloatStateOf(Prefs.volume) }
    var lang by remember { mutableStateOf(Prefs.language) }
    var showVoices by remember { mutableStateOf(false) }
    val spoken by SpeechManager.lastSpoken.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (enabled) Color(0xFFD7F5DD) else Color(0xFFFFDAD6)
            )
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    if (enabled) "Listening ON" else "Listening OFF",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1C1B1F)
                )
                Text(
                    if (enabled) "Payments will be announced" else "Allow Notification Access below",
                    fontSize = 18.sp,
                    color = Color(0xFF1C1B1F)
                )
                if (enabled) {
                    Text(
                        if (SoundboxListenerService.connected) "Service connected" else "Service starting…",
                        fontSize = 14.sp,
                        color = Color(0xFF1C1B1F)
                    )
                }
            }
        }

        Button(
            onClick = {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Cannot open settings", Toast.LENGTH_LONG).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) { Text("Open Notification Access settings", fontSize = 17.sp) }

        OutlinedButton(
            onClick = { requestBatteryExemption(ctx) },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text(
                if (batteryOk) "Battery optimization: exempt ✓" else "Allow background running (battery)",
                fontSize = 17.sp
            )
        }

        Text("Volume", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Slider(
            value = volume,
            onValueChange = { volume = it; Prefs.volume = it },
            valueRange = 0.1f..1f
        )
        Text("Also raise the phone's media volume.", fontSize = 13.sp)

        Text("Voice language", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ne" to "नेपाली", "hi" to "हिन्दी", "en" to "English").forEach { (code, label) ->
                val m = Modifier.weight(1f)
                if (lang == code) {
                    Button(onClick = { }, modifier = m) { Text(label, fontSize = 18.sp) }
                } else {
                    OutlinedButton(
                        onClick = { lang = code; Prefs.language = code },
                        modifier = m
                    ) { Text(label, fontSize = 18.sp) }
                }
            }
        }

        OutlinedButton(
            onClick = { showVoices = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) { Text("🎙 आवाज़ बदलें / Change voice", fontSize = 17.sp) }

        Button(
            onClick = { SpeechManager.speakAmount("500") },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) { Text("🔊 Test voice", fontSize = 18.sp) }

        if (spoken.isNotEmpty()) Text(spoken, fontSize = 14.sp)
    }

    if (showVoices) {
        val voices = remember(lang, showVoices) { SpeechManager.availableVoices(lang) }
        var selected by remember(lang, showVoices) { mutableStateOf(Prefs.voiceFor(lang)) }
        AlertDialog(
            onDismissRequest = { showVoices = false },
            title = { Text("Select voice (${langLabel(lang)})") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    VoiceRow("Default (phone setting)", "", selected.isEmpty()) {
                        selected = ""
                        Prefs.setVoiceFor(lang, "")
                        SpeechManager.speakAmount("500")
                    }
                    voices.forEachIndexed { i, v ->
                        VoiceRow(voiceLabel(v, i), v.name, selected == v.name) {
                            selected = v.name
                            Prefs.setVoiceFor(lang, v.name)
                            SpeechManager.speakAmount("500")
                        }
                    }
                    if (voices.isEmpty()) {
                        Text(
                            "No voices found for this language. Install voice data in the phone's Text-to-speech settings.",
                            fontSize = 14.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showVoices = false }) { Text("Done") } }
        )
    }
}

private fun langLabel(code: String): String = when (code) {
    "ne" -> "Nepali"
    "hi" -> "Hindi"
    else -> "English"
}

private fun voiceLabel(v: android.speech.tts.Voice, index: Int): String {
    val net = if (v.isNetworkConnectionRequired) " – needs internet" else " – offline"
    return "Voice ${index + 1} (${v.locale.toLanguageTag()})$net"
}

@Composable
private fun VoiceRow(title: String, sub: String, selected: Boolean, onPick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onPick() }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Column(Modifier.padding(start = 12.dp)) {
            Text(title, fontSize = 17.sp)
            if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp)
        }
    }
}

// ---------- History ----------

@Composable
fun HistoryScreen() {
    val list by Store.payments.collectAsState()
    val start = remember(list) { startOfToday() }
    val today = list.filter { it.time >= start }
    val total = today.fold(0.0) { acc, p -> acc + p.amount }
    var confirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFD7F5DD))
        ) {
            Column(
                Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Today's total", fontSize = 18.sp, color = Color(0xFF1C1B1F))
                Text(
                    "Rs ${AmountParser.pretty(total)}",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1C1B1F)
                )
                Text("${today.size} payment(s)", fontSize = 16.sp, color = Color(0xFF1C1B1F))
            }
        }
        OutlinedButton(
            onClick = { confirm = true },
            enabled = list.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        ) { Text("Clear history", fontSize = 16.sp) }

        if (list.isEmpty()) {
            Text("No payments yet.", fontSize = 18.sp, modifier = Modifier.padding(top = 16.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            items(list) { p ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Rs ${AmountParser.pretty(p.amount)}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text(fmtTime(p.time), fontSize = 16.sp)
                        Text(fmtDate(p.time), fontSize = 14.sp)
                    }
                }
                HorizontalDivider()
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Clear history?") },
            text = { Text("All saved payments will be deleted from this phone.") },
            confirmButton = {
                TextButton(onClick = { Store.clearPayments(); confirm = false }) { Text("Clear") }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Cancel") }
            }
        )
    }
}

// ---------- Debug log ----------

@Composable
fun DebugScreen() {
    val ctx = LocalContext.current
    val list by Store.debug.collectAsState()
    var on by remember { mutableStateOf(Prefs.debugEnabled) }
    val decision by Store.lastDecision.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            if (decision.isEmpty()) "Last eSewa result: none yet" else "Last eSewa result: $decision",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Capture notifications (all apps)", fontSize = 18.sp, modifier = Modifier.weight(1f))
            Switch(checked = on, onCheckedChange = { on = it; Prefs.debugEnabled = it })
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val txt = list.joinToString("\n\n") {
                        "[${fmtDate(it.time)} ${fmtTime(it.time)}]\npackage: ${it.pkg}\ntitle: ${it.title}\ntext: ${it.text}"
                    }
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Soundbox debug log", txt))
                    Toast.makeText(ctx, "Copied ${list.size} entries", Toast.LENGTH_SHORT).show()
                },
                enabled = list.isNotEmpty(),
                modifier = Modifier.weight(1f)
            ) { Text("Copy all") }
            OutlinedButton(
                onClick = { Store.clearDebug() },
                enabled = list.isNotEmpty(),
                modifier = Modifier.weight(1f)
            ) { Text("Clear") }
        }
        Text("Last ${list.size} of ${Store.MAX_DEBUG} notifications", fontSize = 14.sp)
        if (list.isEmpty()) {
            Text(
                "Nothing captured yet. Make sure Notification Access is ON and this toggle is enabled.",
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
        LazyColumn(Modifier.weight(1f)) {
            items(list) { e ->
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text(
                        "${fmtTime(e.time)}  •  ${e.pkg}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text("Title: ${e.title}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text("Text: ${e.text}", fontSize = 16.sp)
                }
                HorizontalDivider()
            }
        }
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen() {
    var pk by remember { mutableStateOf(Prefs.packagesText) }
    var kw by remember { mutableStateOf(Prefs.keywordsText) }
    var boot by remember { mutableStateOf(Prefs.autoStart) }
    var mx by remember { mutableStateOf(Prefs.maxVolume) }
    var bo by remember { mutableStateOf(Prefs.boost) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = pk,
            onValueChange = { pk = it; Prefs.packagesText = it },
            label = { Text("Allowed package names (one per line)") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = kw,
            onValueChange = { kw = it; Prefs.keywordsText = it },
            label = { Text("\"Received\" keywords (comma separated)") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Notifications containing sent / paid / debited / failed are always ignored.",
            fontSize = 13.sp
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Start automatically after phone restart", fontSize = 18.sp, modifier = Modifier.weight(1f))
            Switch(checked = boot, onCheckedChange = { boot = it; Prefs.autoStart = it })
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Set phone media volume to maximum before each announcement", fontSize = 18.sp, modifier = Modifier.weight(1f))
            Switch(checked = mx, onCheckedChange = { mx = it; Prefs.maxVolume = it })
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Extra loudness boost (+10 dB)", fontSize = 18.sp, modifier = Modifier.weight(1f))
            Switch(checked = bo, onCheckedChange = { bo = it; Prefs.boost = it })
        }

        OutlinedButton(
            onClick = {
                pk = Prefs.DEFAULT_PACKAGES
                kw = Prefs.DEFAULT_KEYWORDS
                Prefs.packagesText = pk
                Prefs.keywordsText = kw
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Reset packages & keywords to default") }
    }
}
