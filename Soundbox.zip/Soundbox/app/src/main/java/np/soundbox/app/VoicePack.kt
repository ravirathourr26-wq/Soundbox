package np.soundbox.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The user's own recorded voice. Words are recorded once and stored on the phone.
 * Item layout (same as FastVoice): 0 = start phrase, 1 = end phrase, 2 = hundred,
 * 3 = thousand, 4 = lakh, 4 + n = number n (1..99).
 */
object VoicePack {
    private const val TAG = "Payment Speaker"
    const val RATE = 16000
    const val TOTAL = 104

    val count = MutableStateFlow(0)
    val version = MutableStateFlow(0)

    private val main = Handler(Looper.getMainLooper())
    private val clips = arrayOfNulls<ShortArray>(TOTAL)
    private val pending = ArrayList<Long>()

    @Volatile
    private var loading = false

    private var recorder: AudioRecord? = null
    private var recThread: Thread? = null
    private var recBuffer: ByteArrayOutputStream? = null

    @Volatile
    private var recording = false

    private fun dir(ctx: Context): File = File(ctx.applicationContext.filesDir, "recorded")

    fun has(idx: Int): Boolean = idx in 0 until TOTAL && clips[idx] != null

    /** Loads saved recordings at app start. Payments that arrive meanwhile wait for it. */
    fun restore(ctx: Context) {
        val d = dir(ctx)
        if (!d.exists()) return
        loading = true
        Thread {
            try {
                for (i in 0 until TOTAL) {
                    val f = File(d, "$i.pcm")
                    if (f.exists()) {
                        val s = bytesToShorts(f.readBytes())
                        if (s.isNotEmpty()) clips[i] = s
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Loading recordings failed", e)
            }
            main.post {
                loading = false
                count.value = clips.count { it != null }
                version.value = version.value + 1
                val waiting = ArrayList(pending)
                pending.clear()
                for (a in waiting) {
                    if (!play(a)) SpeechManager.speakAmount(a.toString())
                }
            }
        }.start()
    }

    /** True if the amount was played (or queued while recordings load) with the recorded voice. */
    fun tryPlay(amount: Long): Boolean {
        if (loading) {
            pending.add(amount)
            return true
        }
        return play(amount)
    }

    fun play(amount: Long): Boolean {
        val ids = FastVoice.phraseIds(amount) ?: return false
        val parts = ArrayList<ShortArray>()
        for (i in ids) {
            val c = clips[i] ?: return false
            parts.add(c)
        }
        FastVoice.playParts(parts, RATE)
        return true
    }

    fun playClip(idx: Int) {
        if (idx !in 0 until TOTAL) return
        val c = clips[idx] ?: return
        FastVoice.playParts(listOf(c), RATE)
    }

    fun startRecording(ctx: Context): Boolean {
        if (recording) return false
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) return false
        return try {
            val minBuf = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf <= 0) return false
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, RATE)
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                r.release()
                return false
            }
            val buffer = ByteArrayOutputStream()
            recBuffer = buffer
            recorder = r
            recording = true
            val t = Thread {
                val buf = ByteArray(4096)
                try {
                    r.startRecording()
                    while (recording) {
                        val n = r.read(buf, 0, buf.size)
                        if (n > 0) buffer.write(buf, 0, n) else if (n < 0) break
                    }
                    r.stop()
                } catch (e: Exception) {
                    Log.w(TAG, "Recording failed", e)
                }
                try {
                    r.release()
                } catch (e: Exception) {
                }
            }
            recThread = t
            t.start()
            true
        } catch (e: SecurityException) {
            false
        } catch (e: Exception) {
            Log.w(TAG, "Could not start recording", e)
            false
        }
    }

    /** Stops, cleans up (trim silence, even out loudness) and saves. False if too short or too quiet. */
    fun stopRecording(ctx: Context, idx: Int): Boolean {
        if (!recording) return false
        recording = false
        try {
            recThread?.join(1500)
        } catch (e: Exception) {
        }
        val bytes = recBuffer?.toByteArray()
        recBuffer = null
        recorder = null
        recThread = null
        if (bytes == null) return false
        val processed = process(bytesToShorts(bytes)) ?: return false
        return try {
            val d = dir(ctx)
            d.mkdirs()
            File(d, "$idx.pcm").writeBytes(shortsToBytes(processed))
            clips[idx] = processed
            count.value = clips.count { it != null }
            version.value = version.value + 1
            if (count.value == 1) Prefs.useRecorded = true
            true
        } catch (e: Exception) {
            Log.w(TAG, "Saving recording failed", e)
            false
        }
    }

    fun deleteAll(ctx: Context) {
        try {
            dir(ctx).listFiles()?.forEach { it.delete() }
        } catch (e: Exception) {
        }
        for (i in 0 until TOTAL) clips[i] = null
        count.value = 0
        version.value = version.value + 1
        Prefs.useRecorded = false
    }

    private fun process(s: ShortArray): ShortArray? {
        if (s.size < RATE / 6) return null
        var peak = 0
        for (v in s) {
            val a = Math.abs(v.toInt())
            if (a > peak) peak = a
        }
        if (peak < 600) return null
        val thr = maxOf(250, (peak * 0.05).toInt())
        var first = -1
        var last = -1
        for (i in s.indices) {
            if (Math.abs(s[i].toInt()) > thr) {
                if (first < 0) first = i
                last = i
            }
        }
        if (first < 0) return null
        val a = maxOf(0, first - RATE / 50)
        val b = minOf(s.size, last + RATE / 12)
        val seg = s.copyOfRange(a, b)
        if (seg.size < RATE / 10) return null
        val gain = minOf(8f, 15000f / peak)
        val out = ShortArray(seg.size)
        for (i in seg.indices) {
            val v = (seg[i] * gain).toInt()
            out[i] = (if (v > 32767) 32767 else if (v < -32768) -32768 else v).toShort()
        }
        return out
    }

    private fun bytesToShorts(b: ByteArray): ShortArray {
        val n = b.size / 2
        val s = ShortArray(n)
        ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(s)
        return s
    }

    private fun shortsToBytes(s: ShortArray): ByteArray {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.asShortBuffer().put(s)
        return bb.array()
    }
}
