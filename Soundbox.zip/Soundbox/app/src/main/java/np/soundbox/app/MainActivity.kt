package np.soundbox.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {

    private var tick by mutableIntStateOf(0)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = android.graphics.Color.parseColor("#F5F7F6")
        window.navigationBarColor = android.graphics.Color.WHITE
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = true
        controller.isAppearanceLightNavigationBars = true

        if (Prefs.keepAlive) KeepAliveService.start(this)

        setContent {
            SoundboxTheme {
                App(tick, onRequestNotifications = { requestNotifications() })
            }
        }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        FastVoice.refresh(this)
        tick++
    }
}

/** Permissions are asked one at a time on clean full-screen pages, never as pop-ups in the app. */
@Composable
fun App(tick: Int, onRequestNotifications: () -> Unit) {
    val ctx = LocalContext.current
    val listenerOn = remember(tick) { isListenerEnabled(ctx) }
    val notifOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }
    val batteryOk = remember(tick) { isIgnoringBattery(ctx) }
    var skipNotif by remember { mutableStateOf(Prefs.skipNotif) }
    var skipBattery by remember { mutableStateOf(Prefs.skipBattery) }
    var skipVoice by remember { mutableStateOf(Prefs.skipVoice) }
    val preparing by FastVoice.preparing.collectAsState()
    val prog by FastVoice.progress.collectAsState()

    when {
        !listenerOn -> OnboardingPage(
            icon = { BellIcon() },
            title = "Enable Notification Access",
            body = "Payment Speaker needs notification access to detect payment alerts and announce them aloud in Nepali.",
            primary = "Start Application",
            onPrimary = { openNotificationAccessSettings(ctx) },
            footnote = "You'll be redirected to system settings",
            extra = "Notifications are read only on your phone to find payment amounts. Nothing is uploaded or shared."
        )

        !notifOk && !skipNotif -> OnboardingPage(
            icon = { BellIcon() },
            title = "Allow Notifications",
            body = "Payment Speaker shows a small \"listening\" notification so Android keeps it running in the background.",
            primary = "Allow",
            onPrimary = onRequestNotifications,
            footnote = "A system permission prompt will appear",
            onSkip = { Prefs.skipNotif = true; skipNotif = true }
        )

        !batteryOk && !skipBattery -> OnboardingPage(
            icon = { BatteryIcon() },
            title = "Keep Payment Speaker Running",
            body = "Allow Payment Speaker to run in the background so payments are announced instantly, even when the screen is off.",
            primary = "Allow Background Running",
            onPrimary = { requestBatteryExemption(ctx) },
            footnote = "You'll be redirected to system settings",
            onSkip = { Prefs.skipBattery = true; skipBattery = true }
        )

        preparing && !skipVoice -> SetupVoicePage(prog) { Prefs.skipVoice = true; skipVoice = true }

        else -> MainShell(tick)
    }
}
