package np.soundbox.app

import android.content.SharedPreferences

object Prefs {
    const val DEFAULT_PACKAGES = "com.f1soft.esewa\ncom.esewa.merchant"
    const val DEFAULT_KEYWORDS = "received, credited, receive, प्राप्त"

    /** Notifications containing any of these words are always ignored. */
    val NEGATIVE_WORDS = listOf(
        "sent", "paid", "debited", "failed", "unsuccessful", "declined",
        "पठाइयो", "पठाएको", "असफल"
    )

    private val sp: SharedPreferences
        get() = Store.prefs

    var packagesText: String
        get() = sp.getString("packages", DEFAULT_PACKAGES) ?: DEFAULT_PACKAGES
        set(v) { sp.edit().putString("packages", v).apply() }

    var keywordsText: String
        get() = sp.getString("keywords", DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS
        set(v) { sp.edit().putString("keywords", v).apply() }

    /** "ne", "hi" or "en" */
    var language: String
        get() = sp.getString("language", "hi") ?: "hi"
        set(v) { sp.edit().putString("language", v).apply() }

    var volume: Float
        get() = sp.getFloat("volume", 1f)
        set(v) { sp.edit().putFloat("volume", v).apply() }

    var debugEnabled: Boolean
        get() = sp.getBoolean("debug_enabled", true)
        set(v) { sp.edit().putBoolean("debug_enabled", v).apply() }

    var autoStart: Boolean
        get() = sp.getBoolean("auto_start", true)
        set(v) { sp.edit().putBoolean("auto_start", v).apply() }

    fun allowedPackages(): Set<String> =
        packagesText.split(Regex("[,;\\s]+")).map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun keywords(): List<String> =
        keywordsText.split(Regex("[,;\\n]+")).map { it.trim().lowercase() }.filter { it.isNotEmpty() }
}
