package np.soundbox.app

import android.content.SharedPreferences

object Prefs {
    const val DEFAULT_PACKAGES = "com.f1soft.esewa\ncom.esewa.merchant"
    const val DEFAULT_KEYWORDS = "received, credited, deposited, receive, प्राप्त, जम्मा"

    /** Notifications containing any of these words are always ignored. */
    val NEGATIVE_WORDS = listOf(
        "sent", "paid", "debited", "failed", "unsuccessful", "declined",
        "पठाइयो", "पठाएको", "असफल"
    )

    /** Whole-word English matches, so names like "Vincent" do not count as "sent". */
    val NEGATIVE_REGEX = Regex("""\b(?:sent|paid|debited|failed|unsuccessful|declined)\b""", RegexOption.IGNORE_CASE)

    /** Chat / social apps that are ignored in "all apps" mode to avoid false announcements. */
    val BLOCKED_PACKAGES = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "com.facebook.orca", "com.facebook.katana",
        "com.facebook.lite", "com.facebook.mlite", "org.telegram.messenger", "com.viber.voip",
        "com.instagram.android", "com.snapchat.android", "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill", "com.imo.android.imoim", "org.thoughtcrime.securesms",
        "com.google.android.gm", "com.google.android.youtube", "com.android.chrome",
        "com.baitu.qingshu", "android"
    )

    private val sp: SharedPreferences
        get() = Store.prefs

    var packagesText: String
        get() = sp.getString("packages", DEFAULT_PACKAGES) ?: DEFAULT_PACKAGES
        set(v) { sp.edit().putString("packages", v).apply() }

    var keywordsText: String
        get() = sp.getString("keywords", DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS
        set(v) { sp.edit().putString("keywords", v).apply() }

    /** "ne", "hi" or "en" */
    var language: String
        get() = sp.getString("language", "hi") ?: "hi"
        set(v) { sp.edit().putString("language", v).apply() }

    var volume: Float
        get() = sp.getFloat("volume", 1f)
        set(v) { sp.edit().putFloat("volume", v).apply() }

    var debugEnabled: Boolean
        get() = sp.getBoolean("debug_enabled", true)
        set(v) { sp.edit().putBoolean("debug_enabled", v).apply() }

    var autoStart: Boolean
        get() = sp.getBoolean("auto_start", true)
        set(v) { sp.edit().putBoolean("auto_start", v).apply() }

    /** Raise the phone's media volume to maximum before every announcement. */
    var maxVolume: Boolean
        get() = sp.getBoolean("max_volume", true)
        set(v) { sp.edit().putBoolean("max_volume", v).apply() }

    /** Extra loudness boost (+10 dB) on the voice. */
    var boost: Boolean
        get() = sp.getBoolean("boost", true)
        set(v) { sp.edit().putBoolean("boost", v).apply() }

    /** Saved TTS voice name for a language ("ne", "hi", "en"); empty = phone default. */
    fun voiceFor(lang: String): String = sp.getString("voice_$lang", "") ?: ""

    fun setVoiceFor(lang: String, name: String) {
        sp.edit().putString("voice_$lang", name).apply()
    }

    /** Show a permanent notification so Android keeps the app alive (recommended). */
    var keepAlive: Boolean
        get() = sp.getBoolean("keep_alive", true)
        set(v) { sp.edit().putBoolean("keep_alive", v).apply() }

    /** Use pre-made voice clips for instant announcements (Hindi / English). */
    var fastMode: Boolean
        get() = sp.getBoolean("fast_mode", true)
        set(v) { sp.edit().putBoolean("fast_mode", v).apply() }

    /** Capture payment notifications from ANY app (except the blocked chat apps). */
    var allApps: Boolean
        get() = sp.getBoolean("all_apps", true)
        set(v) { sp.edit().putBoolean("all_apps", v).apply() }

    /** Name spoken in the announcement, e.g. "QR" -> "QR में 500 रुपये प्राप्त हुए". */
    var announceLabel: String
        get() = sp.getString("label", "QR") ?: "QR"
        set(v) { sp.edit().putString("label", v).apply() }

    /** The user chose "Skip" on the notification-permission page. */
    var skipNotif: Boolean
        get() = sp.getBoolean("skip_notif", false)
        set(v) { sp.edit().putBoolean("skip_notif", v).apply() }

    /** The user chose "Skip" on the battery page. */
    var skipBattery: Boolean
        get() = sp.getBoolean("skip_battery", false)
        set(v) { sp.edit().putBoolean("skip_battery", v).apply() }

    /** Which pre-made voice clips are on disk (so they can be loaded at start without the voice engine). */
    var fastLang: String
        get() = sp.getString("fast_lang", "") ?: ""
        set(v) { sp.edit().putString("fast_lang", v).apply() }

    var fastDirKey: String
        get() = sp.getString("fast_dirkey", "") ?: ""
        set(v) { sp.edit().putString("fast_dirkey", v).apply() }

    var fastLabel: String
        get() = sp.getString("fast_label", "") ?: ""
        set(v) { sp.edit().putString("fast_label", v).apply() }

    fun allowedPackages(): Set<String> =
        packagesText.split(Regex("[,;\\s]+")).map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun keywords(): List<String> =
        keywordsText.split(Regex("[,;\\n]+")).map { it.trim().lowercase() }.filter { it.isNotEmpty() }
}
