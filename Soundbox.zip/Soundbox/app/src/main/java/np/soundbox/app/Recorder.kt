package np.soundbox.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private fun promptTitle(idx: Int): String = when (idx) {
    0 -> "Start phrase"
    1 -> "End phrase"
    2 -> "Hundred"
    3 -> "Thousand"
    4 -> "Lakh"
    else -> "Number " + (idx - 4)
}

private fun promptBig(idx: Int, label: String): String = when (idx) {
    0 -> label + " में / मा"
    1 -> "रुपये प्राप्त हुए / रुपैयाँ प्राप्त भयो"
    2 -> "सौ / सय"
    3 -> "हज़ार / हजार"
    4 -> "लाख"
    else -> (idx - 4).toString()
}

private fun promptHint(idx: Int): String = when (idx) {
    0 -> "Say the start of the sentence, for example “QR mein” (Hindi) or “QR ma” (Nepali)."
    1 -> "Say the ending, for example “rupaye prapt hue” (Hindi) or “rupaiya prapta bhayo” (Nepali)."
    2 -> "Say “hundred” (100) in your language."
    3 -> "Say “thousand” (1,000) in your language."
    4 -> "Say “lakh” (1,00,000) in your language."
    else -> "Say the number " + (idx - 4) + " in your language."
}

@Composable
fun RecorderScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val count by VoicePack.count.collectAsState()
    val version by VoicePack.version.collectAsState()
    var idx by remember { mutableIntStateOf(0) }
    var recording by remember { mutableStateOf(false) }
    var useRec by remember { mutableStateOf(Prefs.useRecorded) }
    var confirmDelete by remember { mutableStateOf(false) }
    var importing by remember { mutableStateOf(false) }
    val label = Prefs.announceLabel.ifBlank { "QR" }
    val recorded = remember(version, idx) { VoicePack.has(idx) }

    fun beginRecording() {
        if (VoicePack.startRecording(ctx)) {
            recording = true
        } else {
            Toast.makeText(ctx, "Could not start the microphone", Toast.LENGTH_SHORT).show()
        }
    }

    fun finishRecording() {
        recording = false
        val ok = VoicePack.stopRecording(ctx, idx)
        if (ok) {
            useRec = Prefs.useRecorded
            if (idx < VoicePack.TOTAL - 1) idx += 1
        } else {
            Toast.makeText(ctx, "Too quiet or too short. Please try again.", Toast.LENGTH_SHORT).show()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            beginRecording()
        } else {
            Toast.makeText(ctx, "Microphone permission is needed to record", Toast.LENGTH_LONG).show()
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty() && !importing) {
            importing = true
            val startIdx = idx
            Thread {
                val sorted = uris.map { Pair(AudioImport.displayName(ctx, it), it) }
                    .sortedWith(compareBy<Pair<String, android.net.Uri>>({ AudioImport.numberIn(it.first) }, { it.first }))
                var ok = 0
                var failed = 0
                for ((n, p) in sorted.withIndex()) {
                    val target = startIdx + n
                    if (target >= VoicePack.TOTAL) break
                    val samples = AudioImport.decode(ctx, p.second)
                    if (samples != null && VoicePack.saveClip(ctx, target, samples)) ok++ else failed++
                }
                Handler(Looper.getMainLooper()).post {
                    importing = false
                    useRec = Prefs.useRecorded
                    idx = minOf(VoicePack.TOTAL - 1, startIdx + sorted.size)
                    val msg = "Uploaded " + ok + " file(s)" + (if (failed > 0) ", " + failed + " could not be used" else "")
                    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                }
            }.start()
        }
    }

    fun toggle() {
        if (recording) {
            finishRecording()
        } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            beginRecording()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brand.Bg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TextButton(onClick = onClose) {
            Text("‹ Back", color = Brand.Green, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("My voice", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Brand.Ink)
        Text(
            "Add your own voice once: record here, or upload audio files. Payment Speaker joins the words to announce payments in your voice. Nothing leaves this phone.",
            fontSize = 14.sp,
            color = Brand.Muted
        )

        SbCard {
            Text("$count of ${VoicePack.TOTAL} recorded", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Brand.Ink)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = count.toFloat() / VoicePack.TOTAL,
                color = Brand.Green,
                trackColor = Brand.GreenLight,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
            )
            Spacer(Modifier.height(8.dp))
            SwitchRow(
                "Use my recorded voice",
                "Amounts not fully covered use the phone voice",
                useRec
            ) {
                useRec = it
                Prefs.useRecorded = it
            }
        }

        SbCard {
            Text("Upload your own audio", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Brand.Ink)
            Spacer(Modifier.height(6.dp))
            Text(
                "Record the words with any recorder app (or WhatsApp voice notes) and name the files 01, 02, 03 ... in the order below. Tap Upload and select them all together. They fill in starting from the item shown further down.",
                fontSize = 13.sp,
                color = Brand.Muted
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "File 1 = start phrase  ·  2 = end phrase  ·  3 = hundred  ·  4 = thousand  ·  5 = lakh  ·  6 = number 1  ·  7 = number 2  ...  104 = number 99",
                fontSize = 13.sp,
                color = Brand.Ink
            )
            Spacer(Modifier.height(10.dp))
            SbButton(
                if (importing) "Uploading..." else "Upload audio files",
                { importLauncher.launch(arrayOf("audio/*")) },
                filled = false,
                enabled = !recording && !importing
            )
        }

        SbCard {
            Text(
                "Item ${idx + 1} of ${VoicePack.TOTAL}  ·  ${promptTitle(idx)}",
                fontSize = 13.sp,
                color = Brand.Muted
            )
            Spacer(Modifier.height(10.dp))
            val big = promptBig(idx, label)
            Text(
                big,
                fontSize = if (big.length > 12) 24.sp else 40.sp,
                fontWeight = FontWeight.Bold,
                color = Brand.Ink,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text(
                promptHint(idx),
                fontSize = 14.sp,
                color = Brand.Muted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Text(
                if (recorded) "✓ Recorded" else "Not recorded yet",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (recorded) Brand.Green else Brand.Warn,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        SbButton(if (recording) "■  Stop" else "●  Record", { toggle() })

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SbButton(
                "Play",
                { VoicePack.playClip(idx) },
                modifier = Modifier.weight(1f),
                filled = false,
                enabled = recorded && !recording
            )
            SbButton(
                "Test 500",
                { SpeechManager.speakAmount("500") },
                modifier = Modifier.weight(1f),
                filled = false,
                enabled = !recording
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SbButton(
                "‹ Previous",
                { if (idx > 0) idx -= 1 },
                modifier = Modifier.weight(1f),
                filled = false,
                enabled = idx > 0 && !recording
            )
            SbButton(
                "Next ›",
                { if (idx < VoicePack.TOTAL - 1) idx += 1 },
                modifier = Modifier.weight(1f),
                filled = false,
                enabled = idx < VoicePack.TOTAL - 1 && !recording
            )
        }
        SbButton(
            "Jump to next missing",
            {
                val m = (0 until VoicePack.TOTAL).firstOrNull { !VoicePack.has(it) }
                if (m != null) idx = m
            },
            filled = false,
            enabled = !recording
        )
        TextButton(onClick = { confirmDelete = true }) {
            Text("Delete all recordings", color = Brand.Bad, fontWeight = FontWeight.SemiBold)
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = Color.White,
            title = { Text("Delete all recordings?") },
            text = { Text("Your recorded words will be removed from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    VoicePack.deleteAll(ctx)
                    useRec = false
                    idx = 0
                    confirmDelete = false
                }) { Text("Delete", color = Brand.Bad) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = Brand.Muted) }
            }
        )
    }
}
