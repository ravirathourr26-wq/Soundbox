package np.soundbox.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun isListenerEnabled(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

fun isIgnoringBattery(ctx: Context): Boolean {
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    return pm.isIgnoringBatteryOptimizations(ctx.packageName)
}

fun requestBatteryExemption(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
        )
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e2: Exception) {
            Toast.makeText(ctx, "Open Settings > Battery manually", Toast.LENGTH_LONG).show()
        }
    }
}

fun openNotificationAccessSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open settings", Toast.LENGTH_LONG).show()
    }
}

fun openAppNotificationSettings(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open settings", Toast.LENGTH_LONG).show()
    }
}

fun startOfToday(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun fmtTime(t: Long): String = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(t))

fun fmtDate(t: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(t))

fun appVersion(ctx: Context): String = try {
    ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
} catch (e: Exception) {
    "?"
}

fun langLabel(code: String): String = when (code) {
    "ne" -> "Nepali"
    "hi" -> "Hindi"
    else -> "English"
}

fun sourceName(pkg: String): String = when {
    pkg == "com.f1soft.esewa" -> "eSewa"
    pkg == "com.esewa.merchant" -> "eSewa Merchant"
    pkg.contains("khalti") -> "Khalti"
    pkg.contains("mms") || pkg.contains("messaging") || pkg.contains("sms") -> "SMS"
    else -> pkg.substringAfterLast('.')
}

fun voiceLabel(v: android.speech.tts.Voice, index: Int): String {
    val net = if (v.isNetworkConnectionRequired) " – needs internet" else " – offline"
    return "Voice ${index + 1} (${v.locale.toLanguageTag()})$net"
}

fun timeAgo(t: Long): String {
    val s = (System.currentTimeMillis() - t) / 1000
    return when {
        s < 60 -> "just now"
        s < 3600 -> (s / 60).toString() + " min ago"
        s < 86400 -> (s / 3600).toString() + " h ago"
        else -> fmtDate(t)
    }
}
