package np.soundbox.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF2E7D32)

/** First screen shown until Notification Access is turned on. */
@Composable
fun OnboardingScreen(onStart: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier
                    .size(120.dp)
                    .background(Color(0xFFE8F5E9), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                BellIcon()
            }
            Spacer(Modifier.height(40.dp))
            Text(
                "Enable Notification Access",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Soundbox needs notification access to detect payment alerts and announce them aloud in Nepali.",
                fontSize = 17.sp,
                color = Color(0xFF616161),
                textAlign = TextAlign.Center,
                lineHeight = 24.sp
            )
            Spacer(Modifier.height(48.dp))
            Button(
                onClick = onStart,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text("Start Application", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "You'll be redirected to system settings",
                fontSize = 13.sp,
                color = Color(0xFF9E9E9E),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun BellIcon() {
    Canvas(Modifier.size(56.dp)) {
        val w = size.width
        val h = size.height
        // dome
        drawArc(
            color = Green,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(0.2f * w, 0.12f * h),
            size = Size(0.6f * w, 0.6f * h)
        )
        // body
        drawRect(color = Green, topLeft = Offset(0.2f * w, 0.42f * h), size = Size(0.6f * w, 0.2f * h))
        // flared bottom
        val flare = Path()
        flare.moveTo(0.2f * w, 0.6f * h)
        flare.lineTo(0.8f * w, 0.6f * h)
        flare.lineTo(0.92f * w, 0.76f * h)
        flare.lineTo(0.08f * w, 0.76f * h)
        flare.close()
        drawPath(flare, Green)
        // clapper
        drawArc(
            color = Green,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(0.38f * w, 0.78f * h),
            size = Size(0.24f * w, 0.16f * h)
        )
        // top knob
        drawCircle(color = Green, radius = 0.06f * w, center = Offset(0.5f * w, 0.1f * h))
    }
}
