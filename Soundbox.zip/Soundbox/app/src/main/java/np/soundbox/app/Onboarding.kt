package np.soundbox.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One full-screen permission page. Shown one at a time instead of pop-ups inside the app. */
@Composable
fun OnboardingPage(
    icon: @Composable () -> Unit,
    title: String,
    body: String,
    primary: String,
    onPrimary: () -> Unit,
    footnote: String,
    onSkip: (() -> Unit)? = null,
    extra: String = ""
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(120.dp)
                    .background(Brand.GreenLight, CircleShape),
                contentAlignment = Alignment.Center
            ) { icon() }
            Spacer(Modifier.height(40.dp))
            Text(
                title,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Brand.Ink,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Text(
                body,
                fontSize = 17.sp,
                color = Brand.Muted,
                textAlign = TextAlign.Center,
                lineHeight = 24.sp
            )
            if (extra.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(
                    extra,
                    fontSize = 13.sp,
                    color = Brand.Muted,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
            Spacer(Modifier.height(48.dp))
            Button(
                onClick = onPrimary,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Brand.Green),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(primary, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                footnote,
                fontSize = 13.sp,
                color = Color(0xFF9E9E9E),
                textAlign = TextAlign.Center
            )
            if (onSkip != null) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onSkip) {
                    Text("Skip for now", color = Brand.Muted, fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
fun BellIcon() {
    Canvas(Modifier.size(56.dp)) {
        val w = size.width
        val h = size.height
        drawArc(
            color = Brand.Green,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(0.2f * w, 0.12f * h),
            size = Size(0.6f * w, 0.6f * h)
        )
        drawRect(color = Brand.Green, topLeft = Offset(0.2f * w, 0.42f * h), size = Size(0.6f * w, 0.2f * h))
        val flare = Path()
        flare.moveTo(0.2f * w, 0.6f * h)
        flare.lineTo(0.8f * w, 0.6f * h)
        flare.lineTo(0.92f * w, 0.76f * h)
        flare.lineTo(0.08f * w, 0.76f * h)
        flare.close()
        drawPath(flare, Brand.Green)
        drawArc(
            color = Brand.Green,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(0.38f * w, 0.78f * h),
            size = Size(0.24f * w, 0.16f * h)
        )
        drawCircle(color = Brand.Green, radius = 0.06f * w, center = Offset(0.5f * w, 0.1f * h))
    }
}

@Composable
fun BatteryIcon() {
    Canvas(Modifier.size(56.dp)) {
        val w = size.width
        val h = size.height
        drawRect(color = Brand.Green, topLeft = Offset(0.08f * w, 0.28f * h), size = Size(0.76f * w, 0.44f * h))
        drawRect(color = Brand.Green, topLeft = Offset(0.84f * w, 0.42f * h), size = Size(0.08f * w, 0.16f * h))
        drawRect(color = Brand.GreenLight, topLeft = Offset(0.14f * w, 0.34f * h), size = Size(0.64f * w, 0.32f * h))
        drawRect(color = Brand.Green, topLeft = Offset(0.18f * w, 0.38f * h), size = Size(0.4f * w, 0.24f * h))
    }
}

/** One-time page shown while the instant voice is being prepared. */
@Composable
fun SetupVoicePage(progress: Float, onSkip: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(120.dp)
                    .background(Brand.GreenLight, CircleShape),
                contentAlignment = Alignment.Center
            ) { SpeakerIcon(Brand.Green, 56.dp) }
            Spacer(Modifier.height(40.dp))
            Text(
                "Setting Up Voice",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Brand.Ink,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Preparing instant payment announcements. This happens only once and takes about a minute. Please keep the app open.",
                fontSize = 17.sp,
                color = Brand.Muted,
                textAlign = TextAlign.Center,
                lineHeight = 24.sp
            )
            Spacer(Modifier.height(40.dp))
            LinearProgressIndicator(
                progress = progress,
                color = Brand.Green,
                trackColor = Brand.GreenLight,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                (progress * 100).toInt().toString() + "%",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Brand.Green
            )
            Spacer(Modifier.height(24.dp))
            TextButton(onClick = onSkip) {
                Text("Skip for now", color = Brand.Muted, fontSize = 15.sp)
            }
        }
    }
}
